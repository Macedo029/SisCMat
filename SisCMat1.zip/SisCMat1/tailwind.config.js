/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['Outfit', 'system-ui', 'sans-serif'],
        body:    ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        sans:    ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        /* Paleta militar pastéis — mapeando as CSS vars para uso no Tailwind */
        'eb-surface':      '#eef1e6',
        'eb-card':         '#f4f6ee',
        'eb-dark':         '#2d371b',
        'eb-dark2':        '#434e2a',
        'eb-text':         '#2d371b',
        'eb-text-sec':     '#5a6642',
        'eb-text-muted':   '#8a9475',
        'eb-border':       'rgba(180,190,160,0.55)',
        'eb-green':        '#3a6642',
        'eb-amber':        '#92600a',
        'eb-red':          '#9b1c1c',
      },
      borderRadius: {
        'neo': '24px',
        'neo-sm': '12px',
        'neo-md': '16px',
        'neo-lg': '20px',
      },
      boxShadow: {
        'card':  '0 2px 8px rgba(45,55,27,0.08), 0 1px 2px rgba(45,55,27,0.04)',
        'card-hover': '0 6px 24px rgba(45,55,27,0.14)',
        'popup': '0 16px 48px rgba(0,0,0,0.18)',
      },
      animation: {
        'float': 'siscmatFloat 7s ease-in-out infinite',
      },
      keyframes: {
        siscmatFloat: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%':      { transform: 'translateY(-7px)' },
        }
      }
    },
  },
  plugins: [],
}
