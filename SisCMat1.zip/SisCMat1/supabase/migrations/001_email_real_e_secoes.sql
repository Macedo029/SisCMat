-- ==============================================================================
-- SisCMat — Migration: Suporte a emails reais + multi-seção para Administrador
-- Aplique este script no Supabase SQL Editor (Project > SQL Editor)
-- ==============================================================================

-- 1. Adicionar coluna para múltiplas seções no perfil (Administrador pode gerenciar várias)
ALTER TABLE public.perfis
  ADD COLUMN IF NOT EXISTS secoes_ids UUID[] DEFAULT '{}';

-- 2. Comentário de auditoria: email é do militar (gmail, outlook, etc.) — NÃO é fictício
COMMENT ON COLUMN public.perfis.email IS 'Email pessoal válido do militar (gmail, outlook, hotmail, yahoo, etc.). Usado como login no Supabase Auth.';
COMMENT ON COLUMN public.perfis.cpf IS 'CPF do militar — identificador único de acesso. Login é feito por CPF+senha.';

-- 3. Tornar a tabela secoes completamente gerenciável pelo Admin:
--    Admins podem INSERT/UPDATE/DELETE seções além de SELECT
DROP POLICY IF EXISTS "Apenas Admin gerencia seções" ON public.secoes;
CREATE POLICY "Admin cria e edita seções" ON public.secoes
  FOR INSERT TO authenticated
  WITH CHECK ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Administrator'));

CREATE POLICY "Admin atualiza seções" ON public.secoes
  FOR UPDATE TO authenticated
  USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Administrator'));

CREATE POLICY "Admin exclui seções" ON public.secoes
  FOR DELETE TO authenticated
  USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Administrator'));

-- 4. Permitir INSERT de perfil também ANTES de autenticação (signUp via anon)
DROP POLICY IF EXISTS "Inserção de perfil inicial" ON public.perfis;
CREATE POLICY "Inserção de perfil inicial" ON public.perfis
  FOR INSERT
  WITH CHECK (
    auth.uid() = id
    OR (SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Section Chief', 'Administrator')
  );

-- 5. Política para INSERT de seção (anon não deve inserir)
--    Seções leitura: qualquer um não-autenticado pode LER (para o formulário de cadastro)
DROP POLICY IF EXISTS "Seções leitura pública para autenticados" ON public.secoes;
CREATE POLICY "Seções leitura pública" ON public.secoes
  FOR SELECT USING (true);

-- 6. Índice para busca por nome de seção
CREATE INDEX IF NOT EXISTS idx_secoes_nome ON public.secoes(nome);
CREATE INDEX IF NOT EXISTS idx_secoes_ativo ON public.secoes(ativo);

-- 7. RPC: Admin atribui seção a um militar
CREATE OR REPLACE FUNCTION public.atribuir_secao_militar(
  p_militar_id UUID,
  p_secao_id   UUID,
  p_nivel      TEXT DEFAULT 'User'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin_nivel TEXT;
BEGIN
  SELECT nivel_acesso INTO v_admin_nivel FROM public.perfis WHERE id = auth.uid();
  IF v_admin_nivel NOT IN ('Administrator', 'Section Chief') THEN
    RETURN jsonb_build_object('success', false, 'message', 'Permissão insuficiente.');
  END IF;

  UPDATE public.perfis SET
    secao_id       = p_secao_id,
    nivel_acesso   = p_nivel::nivel_acesso_enum,
    status_aprovacao = 'Approved',
    aprovado_por   = auth.uid(),
    data_aprovacao = NOW()
  WHERE id = p_militar_id;

  -- Atualizar array de seções gerenciadas (para Administrador multi-seção)
  UPDATE public.perfis SET
    secoes_ids = array_append(COALESCE(secoes_ids, '{}'), p_secao_id)
  WHERE id = p_militar_id AND NOT (p_secao_id = ANY(COALESCE(secoes_ids, '{}')));

  -- Registrar auditoria
  INSERT INTO public.logs_auditoria (tabela, registro_id, acao, autor_id, detalhes)
  VALUES ('perfis', p_militar_id, 'ATRIBUICAO_SECAO', auth.uid(),
    format('Seção ID %s atribuída. Nível: %s', p_secao_id, p_nivel));

  RETURN jsonb_build_object('success', true, 'message', 'Seção atribuída com sucesso.');
END;
$$;

-- 8. RPC: Criar nova seção (Admin)
CREATE OR REPLACE FUNCTION public.criar_secao(
  p_nome     TEXT,
  p_sigla    TEXT,
  p_descricao TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_nivel TEXT;
  v_id    UUID;
BEGIN
  SELECT nivel_acesso INTO v_nivel FROM public.perfis WHERE id = auth.uid();
  IF v_nivel != 'Administrator' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Somente Administradores podem criar seções.');
  END IF;

  INSERT INTO public.secoes (nome, sigla, descricao, ativo)
  VALUES (p_nome, UPPER(p_sigla), p_descricao, true)
  RETURNING id INTO v_id;

  -- Criar expediente padrão para a nova seção
  INSERT INTO public.expediente_secao (secao_id, hora_abertura, hora_fechamento)
  VALUES (v_id, '07:00:00', '17:00:00')
  ON CONFLICT (secao_id) DO NOTHING;

  -- Auditoria
  INSERT INTO public.logs_auditoria (tabela, registro_id, acao, autor_id, detalhes)
  VALUES ('secoes', v_id, 'CRIACAO_SECAO', auth.uid(), format('Seção "%s" (%s) criada.', p_nome, p_sigla));

  RETURN jsonb_build_object('success', true, 'secao_id', v_id, 'message', 'Seção criada com sucesso.');
END;
$$;
