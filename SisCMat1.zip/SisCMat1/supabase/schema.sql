-- ==============================================================================
-- SisCMat - Sistema de Controle de Materiais e Cautela Militar (Exército Brasileiro)
-- Schema PostgreSQL Completo para Produção com Supabase, RLS, RPCs, Fingerprint, 
-- Controle de Expediente, Exceções e Auditoria Imutável
-- ==============================================================================

-- 1. EXTENSÕES
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
DO $$ BEGIN
    CREATE TYPE nivel_acesso_enum AS ENUM ('User', 'Material Operator', 'Section Chief', 'Administrator', 'Auditor');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE status_aprovacao_enum AS ENUM ('Pending', 'Approved', 'Rejected', 'Suspended');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE status_cautela_enum AS ENUM ('pendente', 'ativa', 'devolvida', 'recusada', 'aguardando_excecao');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE tipo_foto_enum AS ENUM ('entrega', 'devolucao');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- 3. SEÇÕES MILITARES
CREATE TABLE IF NOT EXISTS public.secoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(100) NOT NULL UNIQUE,
    sigla VARCHAR(20) NOT NULL UNIQUE,
    descricao TEXT,
    chefe_id UUID, -- Referência circular tratada via FK no final
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Inserção de Seções Iniciais da OM
INSERT INTO public.secoes (nome, sigla, descricao) VALUES
('Reserva de Armas - 1ª Cia', 'ARMAS-1CIA', 'Armaria principal da Primeira Companhia de Fuzileiros'),
('Almoxarifado Geral', 'ALMOX-GERAL', 'Depósito central de suprimentos da Organização Militar'),
('Pelotão de Comunicações', 'PEL-COM', 'Equipamentos de rádio, óptica e eletrônica tática'),
('Subtenência da 2ª Cia', 'SUB-2CIA', 'Material de acampamento, ferramentas e instrução')
ON CONFLICT (sigla) DO NOTHING;

-- 4. PERFIS MILITARES & SOLICITAÇÕES DE ACESSO
CREATE TABLE IF NOT EXISTS public.perfis (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    nome_completo VARCHAR(150) NOT NULL,
    nome_guerra VARCHAR(60) NOT NULL,
    posto_graduacao VARCHAR(50) NOT NULL,
    email VARCHAR(150) NOT NULL,
    secao_id UUID REFERENCES public.secoes(id) ON DELETE SET NULL,
    secao_solicitada VARCHAR(100),
    nivel_acesso nivel_acesso_enum NOT NULL DEFAULT 'User',
    status_aprovacao status_aprovacao_enum NOT NULL DEFAULT 'Pending',
    motivo_decisao TEXT,
    aprovado_por UUID,
    data_aprovacao TIMESTAMPTZ,
    avatar_url TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    custom_permissions JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_perfis_cpf ON public.perfis(cpf);
CREATE INDEX IF NOT EXISTS idx_perfis_secao ON public.perfis(secao_id);
CREATE INDEX IF NOT EXISTS idx_perfis_status ON public.perfis(status_aprovacao);
CREATE INDEX IF NOT EXISTS idx_perfis_posto ON public.perfis(posto_graduacao);

-- Adicionar FK de chefe na tabela secoes
ALTER TABLE public.secoes 
    ADD CONSTRAINT fk_secoes_chefe 
    FOREIGN KEY (chefe_id) REFERENCES public.perfis(id) ON DELETE SET NULL;

-- 5. FINGERPRINT & SESSÕES DE DISPOSITIVOS
CREATE TABLE IF NOT EXISTS public.sessoes_dispositivos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    militar_id UUID NOT NULL REFERENCES public.perfis(id) ON DELETE CASCADE,
    token_sessao TEXT NOT NULL,
    ip_origem VARCHAR(45) NOT NULL,
    dispositivo VARCHAR(100),
    sistema_operacional VARCHAR(100),
    navegador VARCHAR(100),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_acesso TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessoes_militar ON public.sessoes_dispositivos(militar_id, ativo);

-- 6. EXPEDIENTE MILITAR DA SEÇÃO
CREATE TABLE IF NOT EXISTS public.expediente_secao (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    secao_id UUID NOT NULL REFERENCES public.secoes(id) ON DELETE CASCADE UNIQUE,
    hora_abertura TIME NOT NULL DEFAULT '07:00:00',
    hora_fechamento TIME NOT NULL DEFAULT '17:00:00',
    dias_semana INT[] DEFAULT ARRAY[1,2,3,4,5], -- 1=Segunda, 5=Sexta
    bloquear_fora_expediente BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Inserir expedientes padrão
INSERT INTO public.expediente_secao (secao_id, hora_abertura, hora_fechamento)
SELECT id, '07:00:00'::TIME, '17:00:00'::TIME FROM public.secoes
ON CONFLICT (secao_id) DO NOTHING;

-- 7. CATÁLOGO DE MATERIAIS
CREATE TABLE IF NOT EXISTS public.materiais (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    numero_patrimonio VARCHAR(100) NOT NULL UNIQUE,
    nome VARCHAR(120) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(60) NOT NULL DEFAULT 'Geral',
    secao_id UUID NOT NULL REFERENCES public.secoes(id) ON DELETE RESTRICT,
    numero_lacre_atual VARCHAR(50),
    estado_fisico TEXT NOT NULL DEFAULT 'Excelente estado de conservação',
    quantidade_total INT NOT NULL DEFAULT 1,
    quantidade_disponivel INT NOT NULL DEFAULT 1,
    status_disponibilidade VARCHAR(30) NOT NULL DEFAULT 'disponivel', -- disponivel, cautelado, manutencao
    foto_capa_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_materiais_patrimonio ON public.materiais(numero_patrimonio);
CREATE INDEX IF NOT EXISTS idx_materiais_secao ON public.materiais(secao_id);

-- 8. CAUTELAS & EXCEÇÕES FORA DE EXPEDIENTE
CREATE TABLE IF NOT EXISTS public.cautelas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    militar_id UUID NOT NULL REFERENCES public.perfis(id) ON DELETE RESTRICT,
    material_id UUID NOT NULL REFERENCES public.materiais(id) ON DELETE RESTRICT,
    chefe_autorizador_id UUID REFERENCES public.perfis(id) ON DELETE RESTRICT,
    chefe_encerrador_id UUID REFERENCES public.perfis(id) ON DELETE RESTRICT,
    status status_cautela_enum NOT NULL DEFAULT 'ativa',
    
    -- Lacres e Registros Físicos
    lacre_saida VARCHAR(50) NOT NULL,
    lacre_retorno VARCHAR(50),
    observacoes_saida TEXT,
    observacoes_retorno TEXT,
    
    -- Exceção Fora de Expediente
    fora_expediente BOOLEAN NOT NULL DEFAULT FALSE,
    motivo_excecao TEXT,
    excecao_aprovada_por UUID REFERENCES public.perfis(id),
    
    -- Datas e Horários Precisos de Retirada e Devolução
    data_solicitacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_retirada TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_prevista_devolucao TIMESTAMPTZ,
    data_devolucao TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cautelas_militar ON public.cautelas(militar_id);
CREATE INDEX IF NOT EXISTS idx_cautelas_material ON public.cautelas(material_id);
CREATE INDEX IF NOT EXISTS idx_cautelas_status ON public.cautelas(status);

-- 9. FOTOS EM LOTE DA CAUTELA (ENTREGA / DEVOLUÇÃO)
CREATE TABLE IF NOT EXISTS public.cautela_fotos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cautela_id UUID NOT NULL REFERENCES public.cautelas(id) ON DELETE CASCADE,
    tipo tipo_foto_enum NOT NULL, -- entrega ou devolucao
    foto_url TEXT NOT NULL,
    legenda VARCHAR(200),
    numero_lacre_visivel VARCHAR(50),
    criado_por UUID REFERENCES public.perfis(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. LOGS DE AUDITORIA IMUTÁVEIS
CREATE TABLE IF NOT EXISTS public.logs_auditoria (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tabela VARCHAR(50) NOT NULL,
    registro_id UUID NOT NULL,
    acao VARCHAR(40) NOT NULL, -- APROVACAO_ACESSO, REVOGACAO, CAUTELA_ABERTA, CAUTELA_ENCERRADA, EXCECAO_APROVADA
    autor_id UUID REFERENCES public.perfis(id),
    autor_nome VARCHAR(150),
    dados_anteriores JSONB,
    dados_novos JSONB,
    detalhes TEXT,
    ip_origem VARCHAR(45),
    dispositivo_info VARCHAR(150),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auditoria_tabela ON public.logs_auditoria(tabela, registro_id);

-- 11. TRIGGERS DE UPDATED_AT
CREATE OR REPLACE FUNCTION update_timestamp_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_perfis_modtime BEFORE UPDATE ON public.perfis FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();
CREATE TRIGGER update_secoes_modtime BEFORE UPDATE ON public.secoes FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();
CREATE TRIGGER update_materiais_modtime BEFORE UPDATE ON public.materiais FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();
CREATE TRIGGER update_cautelas_modtime BEFORE UPDATE ON public.cautelas FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

-- 12. ROW LEVEL SECURITY (RLS)
ALTER TABLE public.perfis ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.secoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sessoes_dispositivos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expediente_secao ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.materiais ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cautelas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cautela_fotos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logs_auditoria ENABLE ROW LEVEL SECURITY;

-- POLÍTICAS: PERFIS
CREATE POLICY "Perfis visíveis por todos os autenticados" ON public.perfis FOR SELECT TO authenticated USING (true);
CREATE POLICY "Perfis editáveis por próprio ou Admin" ON public.perfis FOR UPDATE TO authenticated USING (auth.uid() = id OR (SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) = 'Administrator');
CREATE POLICY "Inserção de perfil inicial" ON public.perfis FOR INSERT TO authenticated WITH CHECK (auth.uid() = id OR (SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Section Chief', 'Administrator'));

-- POLÍTICAS: SEÇÕES
CREATE POLICY "Seções leitura pública para autenticados" ON public.secoes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Apenas Admin gerencia seções" ON public.secoes FOR ALL TO authenticated USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) = 'Administrator');

-- POLÍTICAS: MATERIAIS
CREATE POLICY "Materiais leitura por autenticados" ON public.materiais FOR SELECT TO authenticated USING (true);
CREATE POLICY "Gestão de materiais por Operador, Chefe e Admin" ON public.materiais FOR ALL TO authenticated USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Material Operator', 'Section Chief', 'Administrator'));

-- POLÍTICAS: CAUTELAS
CREATE POLICY "Leitura de cautelas" ON public.cautelas FOR SELECT TO authenticated USING (true);
CREATE POLICY "Inserção e encerramento de cautelas" ON public.cautelas FOR ALL TO authenticated USING (true);
CREATE POLICY "PROIBIDO HARD DELETE EM CAUTELAS" ON public.cautelas FOR DELETE TO authenticated USING (false);

-- POLÍTICAS: FOTOS & SESSÕES
CREATE POLICY "Fotos leitura e escrita" ON public.cautela_fotos FOR ALL TO authenticated USING (true);
CREATE POLICY "Gestão das próprias sessões" ON public.sessoes_dispositivos FOR ALL TO authenticated USING (militar_id = auth.uid() OR (SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) = 'Administrator');
CREATE POLICY "Expediente leitura por todos" ON public.expediente_secao FOR SELECT TO authenticated USING (true);
CREATE POLICY "Expediente edição por Chefe e Admin" ON public.expediente_secao FOR ALL TO authenticated USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Section Chief', 'Administrator'));
CREATE POLICY "Auditoria leitura por Auditor e Admin" ON public.logs_auditoria FOR SELECT TO authenticated USING ((SELECT nivel_acesso FROM public.perfis WHERE id = auth.uid()) IN ('Auditor', 'Administrator', 'Section Chief'));

-- 13. BUCKETS DE STORAGE
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('materiais-fotos', 'materiais-fotos', true) ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Storage avatars upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'avatars');
CREATE POLICY "Storage avatars select" ON storage.objects FOR SELECT TO public USING (bucket_id = 'avatars');
CREATE POLICY "Storage materiais-fotos upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'materiais-fotos');
CREATE POLICY "Storage materiais-fotos select" ON storage.objects FOR SELECT TO public USING (bucket_id = 'materiais-fotos');
