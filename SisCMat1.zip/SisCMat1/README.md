# SisCMat — Sistema de Controle de Materiais e Cautela Militar (Exército Brasileiro)

Sistema digital para blindar a cadeia de custódia de suprimentos e armamentos em Batalhão do Exército Brasileiro (EB), substituindo o livro de cautelas impresso.

---

## 🛠️ Stack Tecnológica & Infraestrutura

- **Front-End & Framer:** React, Framer Motion, `@phosphor-icons/react`, Soft-Neomorphism CSS System.
- **Back-End / Banco de Dados:** Supabase (PostgreSQL 15+ com RLS e Buckets de Storage).
- **Storage Buckets:** `avatars` (perfis militares) e `materiais-fotos` (mídias dos lotes de carga e lacres).

---

## 🚀 Como Aplicar o Schema SQL no Supabase

1. Acesse o painel do seu projeto no Supabase: [https://supabase.com/dashboard/project/gvaensyydjfmnfalrpxa](https://supabase.com/dashboard/project/gvaensyydjfmnfalrpxa)
2. Vá até o menu **SQL Editor** no painel esquerdo.
3. Abra o arquivo [`supabase/schema.sql`](./supabase/schema.sql) deste repositório, copie todo o conteúdo e cole no SQL Editor.
4. Clique em **Run** para criar as tabelas (`perfis`, `secoes`, `materiais`, `cautelas`, `cautela_fotos`, `logs_auditoria`), enums, políticas de RLS e buckets do Supabase Storage (`avatars` e `materiais-fotos`).

---

## 📦 Estrutura de Arquivos Gerados

- [`supabase/schema.sql`](./supabase/schema.sql): Schema PostgreSQL completo com RLS por hierarquia e buckets.
- [`.env`](./.env): Variáveis de ambiente configuradas com a URL e chaves do seu projeto.
- [`src/lib/supabaseClient.js`](./src/lib/supabaseClient.js): Inicializador do Supabase com sessão de 90 dias, formatadores de CPF e helpers de upload.
- [`src/styles/neomorphism.css`](./src/styles/neomorphism.css): Sistema visual Soft-Neomorphism (border-radius: 24px, backdrop blur, Antigravity clamp e animação vertical).
- [`src/components/CadastroMilitar.jsx`](./src/components/CadastroMilitar.jsx): Formulário de Cadastro Militar com validação de CPF, postos/graduações, foto de perfil e nível de acesso.
- [`src/components/UploadFotosLacres.jsx`](./src/components/UploadFotosLacres.jsx): Módulo de Upload em Lote de Fotos de Lacres e Carga com grade de pré-visualização.
- [`src/framer/SisCMatOverrides.js`](./src/framer/SisCMatOverrides.js): Código pronto para Code Overrides e Code Components no Framer.

---

## 🎨 Como Usar no Editor Visual do Framer

No Framer:

1. Crie um novo **Code Component** ou **Code Override** na barra lateral.
2. Copie o conteúdo de [`src/framer/SisCMatOverrides.js`](./src/framer/SisCMatOverrides.js) ou importe os componentes `CadastroMilitar` e `UploadFotosLacres`.
3. Arraste para a tela visual (Canvas) ou aplique o Override aos seus Frames!

---

## 💻 Rodar Localmente (Vite)

Para testar no navegador localmente:

```bash
npm run dev
```

Abra no navegador em `http://localhost:3000`.
