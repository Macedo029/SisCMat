import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Camera, 
  Seal, 
  QrCode, 
  UploadSimple, 
  Trash, 
  CheckCircle, 
  WarningCircle, 
  SpinnerGap,
  Image as ImageIcon,
  ArrowRight
} from '@phosphor-icons/react';
import { supabase, uploadFotosLacre } from '../lib/supabaseClient.js';
import '../styles/neomorphism.css';

export function UploadFotosLacres({ cautelaId, defaultPatrimonio = '', defaultLacre = '', onCompleted, className = '' }) {
  const [numeroPatrimonio, setNumeroPatrimonio] = useState(defaultPatrimonio);
  const [numeroLacre, setNumeroLacre] = useState(defaultLacre);
  const [tipoEtapa, setTipoEtapa] = useState('entrega'); // 'entrega' | 'devolucao'
  const [observacoes, setObservacoes] = useState('');
  
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  // Manipular seleção de arquivos de imagem em lote
  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const newFiles = [...selectedFiles, ...files];
    setSelectedFiles(newFiles);

    const newPreviews = files.map(file => URL.createObjectURL(file));
    setPreviews(prev => [...prev, ...newPreviews]);
  };

  const handleRemoveFile = (index) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newPreviews = previews.filter((_, i) => i !== index);
    setSelectedFiles(newFiles);
    setPreviews(newPreviews);
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    setFeedback(null);

    if (!numeroLacre) {
      setFeedback({ type: 'error', message: 'O número do lacre é obrigatório para registrar a custódia.' });
      return;
    }

    if (selectedFiles.length === 0) {
      setFeedback({ type: 'error', message: 'Selecione ao menos uma foto do lacre ou material em lote.' });
      return;
    }

    setUploading(true);

    try {
      const activeCautelaId = cautelaId || `temp_cautela_${Date.now()}`;
      
      // 1. Upload do lote de fotos para o bucket 'materiais-fotos'
      const uploadedUrls = await uploadFotosLacre(selectedFiles, activeCautelaId, tipoEtapa);

      // 2. Gravar os registros na tabela 'cautela_fotos'
      if (cautelaId && uploadedUrls.length > 0) {
        const fotoRecords = uploadedUrls.map(url => ({
          cautela_id: cautelaId,
          tipo: tipoEtapa,
          foto_url: url,
          legenda: observacoes || `Foto de ${tipoEtapa} - Lacre: ${numeroLacre}`,
          numero_lacre_visivel: numeroLacre
        }));

        const { error: dbError } = await supabase.from('cautela_fotos').insert(fotoRecords);
        if (dbError) {
          console.warn('Fotos enviadas para o bucket, mas aviso ao salvar metadados no banco:', dbError);
        }
      }

      setFeedback({
        type: 'success',
        message: `Lote de ${uploadedUrls.length} foto(s) e registro do Lacre #${numeroLacre} gravados com sucesso!`
      });

      // Limpar seleção
      setSelectedFiles([]);
      setPreviews([]);
      setObservacoes('');

      if (onCompleted) onCompleted({ uploadedUrls, numeroLacre, numeroPatrimonio });

    } catch (err) {
      console.error('Erro ao registrar fotos do lacre:', err);
      setFeedback({ type: 'error', message: err.message || 'Erro ao realizar upload das mídias.' });
    } finally {
      setUploading(false);
    }
  };

  return (
    <motion.div
      className={`neo-card antigravity-float ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      style={{ maxWidth: '640px', width: '100%', margin: '0 auto' }}
    >
      {/* Cabeçalho */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '20px' }}>
        <div style={{
          width: '48px',
          height: '48px',
          borderRadius: '16px',
          background: 'rgba(16, 185, 129, 0.15)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--accent-tactical)',
          border: '1px solid rgba(16, 185, 129, 0.3)'
        }}>
          <Camera size={28} weight="duotone" />
        </div>
        <div>
          <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: 'var(--text-main)' }}>
            Registro de Lacres e Custódia Físico-Digital
          </h2>
          <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: 'var(--text-muted)' }}>
            Upload em Lote de Mídias e Inspeção de Cautela
          </p>
        </div>
      </div>

      {/* Alerta de Feedback */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            style={{
              padding: '12px 16px',
              borderRadius: '16px',
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              fontSize: '14px',
              background: feedback.type === 'success' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
              border: `1px solid ${feedback.type === 'success' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
              color: feedback.type === 'success' ? 'var(--accent-tactical)' : 'var(--accent-danger)'
            }}
          >
            {feedback.type === 'success' ? <CheckCircle size={20} weight="bold" /> : <WarningCircle size={20} weight="bold" />}
            <span>{feedback.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleUploadSubmit}>
        {/* Toggle Etapa: Entrega ou Devolução */}
        <div style={{
          display: 'flex',
          background: 'var(--bg-input)',
          padding: '4px',
          borderRadius: '16px',
          border: 'var(--border-neomorph)',
          marginBottom: '20px'
        }}>
          <button
            type="button"
            onClick={() => setTipoEtapa('entrega')}
            style={{
              flex: 1,
              padding: '10px',
              borderRadius: '12px',
              border: 'none',
              background: tipoEtapa === 'entrega' ? 'var(--primary-blue)' : 'transparent',
              color: '#ffffff',
              fontWeight: 600,
              fontSize: '13px',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            Entrega / Retirada do Material
          </button>
          <button
            type="button"
            onClick={() => setTipoEtapa('devolucao')}
            style={{
              flex: 1,
              padding: '10px',
              borderRadius: '12px',
              border: 'none',
              background: tipoEtapa === 'devolucao' ? 'var(--accent-tactical)' : 'transparent',
              color: '#ffffff',
              fontWeight: 600,
              fontSize: '13px',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            Devolução à Armaria / Almoxarifado
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
          {/* Número do Lacre */}
          <div className="neo-input-group">
            <label className="neo-label">
              <Seal size={18} weight="duotone" /> Número do Lacre Físico
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><Seal size={20} /></div>
              <input
                type="text"
                className="neo-input"
                placeholder="Ex: LAC-2026-8849"
                value={numeroLacre}
                onChange={(e) => setNumeroLacre(e.target.value)}
                required
              />
            </div>
          </div>

          {/* Número de Patrimônio */}
          <div className="neo-input-group">
            <label className="neo-label">
              <QrCode size={18} weight="duotone" /> Nº de Patrimônio / Série
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><QrCode size={20} /></div>
              <input
                type="text"
                className="neo-input"
                placeholder="Ex: EB-PAT-90382"
                value={numeroPatrimonio}
                onChange={(e) => setNumeroPatrimonio(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Observações do Estado Físico */}
        <div className="neo-input-group">
          <label className="neo-label">Observações sobre o Estado Físico</label>
          <textarea
            className="neo-input"
            style={{ minHeight: '70px', resize: 'vertical' }}
            placeholder="Registre arranhões, integridade da trava, estado do lacre de segurança..."
            value={observacoes}
            onChange={(e) => setObservacoes(e.target.value)}
          />
        </div>

        {/* Área de Drop / Seleção de Fotos */}
        <div style={{ marginBottom: '20px' }}>
          <label className="neo-label" style={{ marginBottom: '8px' }}>
            <ImageIcon size={18} weight="duotone" /> Fotos em Lote (Lacres e Ângulos de Carga)
          </label>
          
          <label style={{ cursor: 'pointer', display: 'block' }}>
            <div style={{
              padding: '24px',
              borderRadius: '24px',
              background: 'var(--bg-input)',
              border: '2px dashed rgba(59, 130, 246, 0.4)',
              textAlign: 'center',
              transition: 'border-color 0.2s ease'
            }}>
              <UploadSimple size={36} weight="duotone" style={{ color: 'var(--primary-blue)', marginBottom: '8px' }} />
              <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-main)' }}>
                Clique ou arraste as fotos aqui
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>
                Suporta múltiplas imagens (JPG, PNG, WEBP)
              </div>
            </div>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              style={{ display: 'none' }}
            />
          </label>
        </div>

        {/* Grid de Previsualização de Fotos em Lote */}
        {previews.length > 0 && (
          <div style={{ marginBottom: '24px' }}>
            <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginBottom: '10px' }}>
              Fotos selecionadas para envio ({previews.length}):
            </div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(90px, 1fr))',
              gap: '12px'
            }}>
              {previews.map((src, idx) => (
                <div key={idx} style={{
                  position: 'relative',
                  width: '100%',
                  height: '90px',
                  borderRadius: '16px',
                  overflow: 'hidden',
                  border: 'var(--border-neomorph)'
                }}>
                  <img src={src} alt={`Preview ${idx + 1}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <button
                    type="button"
                    onClick={() => handleRemoveFile(idx)}
                    style={{
                      position: 'absolute',
                      top: '4px',
                      right: '4px',
                      background: 'rgba(239, 68, 68, 0.85)',
                      border: 'none',
                      borderRadius: '50%',
                      width: '24px',
                      height: '24px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: '#fff',
                      cursor: 'pointer'
                    }}
                  >
                    <Trash size={14} weight="bold" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Botão de Envio */}
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button
            type="submit"
            className="neo-button neo-button-primary"
            disabled={uploading}
            style={{ width: '100%', maxWidth: '300px' }}
          >
            {uploading ? (
              <>
                <SpinnerGap size={20} className="antigravity-float" style={{ animationDuration: '1s' }} />
                <span>Enviando Lote de Mídias...</span>
              </>
            ) : (
              <>
                <CheckCircle size={20} weight="bold" />
                <span>Registrar Fotos & Lacre</span>
                <ArrowRight size={18} weight="bold" />
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
}
