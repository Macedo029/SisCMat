import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { House, Package, ClipboardText, ShieldCheck, CaretLeft, CaretRight, SignOut } from '@phosphor-icons/react';
import { canAccess } from '../lib/SisCMatAccessPolicy.ts';

const C = {
  dark:    '#2d371b',
  olive:   '#434e2a',
  sec:     '#5a6642',
  muted:   '#8a9475',
  card:    '#f4f6ee',
  surface: '#eef1e6',
  border:  'rgba(180,190,160,0.55)',
  green:   '#3a6642',
  inv:     '#f4f6ee',
};

const ROUTES = [
  { path: '/app/dashboard', label: 'Dashboard',    icon: House,         module: 'dashboard', action: 'view' },
  { path: '/app/materiais', label: 'Materiais',     icon: Package,       module: 'materiais', action: 'view' },
  { path: '/app/cautelas',  label: 'Cautelas',      icon: ClipboardText, module: 'cautelas',  action: 'view' },
  { path: '/app/admin',     label: 'Administração', icon: ShieldCheck,   module: 'admin',     action: 'view' },
];

export function Sidebar({ currentPath, onNavigate, userPerfil, onLogout }) {
  const [collapsed, setCollapsed] = useState(false);
  const ease = { duration: 0.2, ease: [0.4, 0, 0.2, 1] };

  const authorizedRoutes = ROUTES.filter(r => {
    if (!r.module) return true;
    try {
      return canAccess(userPerfil, r.module, r.action, {
        targetUserId: userPerfil?.id,
        targetSection: userPerfil?.secao?.nome || userPerfil?.secao_solicitada
      });
    } catch { return true; }
  });

  const initials = userPerfil?.nome_guerra
    ? userPerfil.nome_guerra.slice(0, 2).toUpperCase()
    : 'EB';

  return (
    <>
      {/* ── DESKTOP SIDEBAR ─────────────────────────────────────────────── */}
      <motion.aside
        animate={{ width: collapsed ? 72 : 240 }}
        transition={ease}
        className="hidden md:flex flex-col justify-between h-screen sticky top-0 z-30 select-none overflow-hidden"
        style={{ background: '#1a2211', color: C.inv, flexShrink: 0, boxShadow: '4px 0 20px rgba(0,0,0,0.15)' }}
      >
        {/* Topo */}
        <div style={{ padding: 16 }} className="space-y-6">
          {/* Logo */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="icon-box icon-box-md flex-shrink-0"
                style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.10)', color: '#86efac' }}>
                <ShieldCheck size={22} weight="duotone" />
              </div>
              {!collapsed && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={ease} className="overflow-hidden">
                  <p className="t-subtitle" style={{ color: '#ffffff', lineHeight: 1 }}>SisCMat</p>
                  <span style={{ fontSize: 10, color: '#86efac', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                    Logística Militar
                  </span>
                </motion.div>
              )}
            </div>
            <button
              onClick={() => setCollapsed(!collapsed)}
              style={{ padding: 6, borderRadius: 10, background: 'rgba(255,255,255,0.06)', color: 'rgba(244,246,238,0.5)', border: 'none', cursor: 'pointer' }}
              title={collapsed ? 'Expandir' : 'Recolher'}
            >
              {collapsed ? <CaretRight size={15} /> : <CaretLeft size={15} />}
            </button>
          </div>

          {/* Nav */}
          <nav className="space-y-1">
            {!collapsed && <p className="section-label" style={{ color: 'rgba(244,246,238,0.35)', padding: '0 8px', marginBottom: 6 }}>Navegação</p>}
            {authorizedRoutes.map((route) => {
              const Icon = route.icon;
              const active = currentPath === route.path;
              return (
                <button
                  key={route.path}
                  onClick={() => onNavigate(route.path)}
                  title={collapsed ? route.label : undefined}
                  className="w-full flex items-center gap-3 transition-all duration-200"
                  style={{
                    padding: '10px 12px',
                    borderRadius: 16,
                    border: active ? '1px solid rgba(134,239,172,0.2)' : '1px solid transparent',
                    background: active ? 'rgba(134,239,172,0.10)' : 'transparent',
                    color: active ? '#ffffff' : 'rgba(244,246,238,0.52)',
                    cursor: 'pointer',
                  }}
                >
                  <Icon size={20} weight={active ? 'fill' : 'duotone'}
                    color={active ? '#86efac' : 'rgba(244,246,238,0.45)'}
                    style={{ flexShrink: 0 }} />
                  {!collapsed && (
                    <span style={{ fontSize: 14, fontWeight: active ? 700 : 500, flex: 1, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {route.label}
                    </span>
                  )}
                  {active && !collapsed && (
                    <span style={{ width: 4, height: 16, borderRadius: 999, background: '#86efac', flexShrink: 0 }} />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* User card */}
        <div style={{ padding: 16, borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <div className="flex items-center gap-3" style={{ padding: 10, borderRadius: 16, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <div className="icon-box icon-box-md flex-shrink-0" style={{ background: 'rgba(134,239,172,0.15)', border: '1px solid rgba(134,239,172,0.2)', color: '#86efac', fontSize: 12, fontWeight: 800 }}>
              {userPerfil?.avatar_url
                ? <img src={userPerfil.avatar_url} alt="Avatar" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 12 }} />
                : initials}
            </div>
            {!collapsed && (
              <>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 13, fontWeight: 600, color: '#ffffff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {userPerfil?.posto_graduacao} {userPerfil?.nome_guerra || 'Militar'}
                  </p>
                  <p style={{ fontSize: 11, color: 'rgba(244,246,238,0.40)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', letterSpacing: 0, textTransform: 'none' }}>
                    {userPerfil?.secao?.sigla || userPerfil?.secao_solicitada || 'Sem Seção'}
                  </p>
                </div>
                <button onClick={onLogout} title="Sair"
                  style={{ padding: 6, borderRadius: 8, color: 'rgba(244,246,238,0.4)', background: 'transparent', border: 'none', cursor: 'pointer', flexShrink: 0, transition: 'color 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#fca5a5'}
                  onMouseLeave={e => e.currentTarget.style.color = 'rgba(244,246,238,0.4)'}
                >
                  <SignOut size={16} />
                </button>
              </>
            )}
          </div>
        </div>
      </motion.aside>

      {/* ── MOBILE BOTTOM DOCK ──────────────────────────────────────────── */}
      <nav className="md:hidden fixed bottom-3 left-3 right-3 z-40 flex items-center justify-around"
        style={{ background: 'rgba(244,246,238,0.97)', backdropFilter: 'blur(12px)', border: '1px solid rgba(180,190,160,0.55)', borderRadius: 24, padding: 8, boxShadow: '0 8px 32px rgba(0,0,0,0.14)' }}>
        {authorizedRoutes.map((route) => {
          const Icon = route.icon;
          const active = currentPath === route.path;
          return (
            <button key={route.path} onClick={() => onNavigate(route.path)}
              className="flex flex-col items-center gap-1 transition-all duration-200"
              style={{ padding: '8px 12px', borderRadius: 16, background: active ? 'rgba(67,78,42,0.10)' : 'transparent', border: 'none', cursor: 'pointer' }}>
              <Icon size={21} weight={active ? 'fill' : 'regular'} color={active ? C.olive : C.muted} />
              <span style={{ fontSize: 10, fontWeight: active ? 700 : 500, color: active ? C.dark : C.muted }}>
                {route.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
