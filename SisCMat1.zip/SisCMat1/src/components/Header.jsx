import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, ShieldCheck, Devices, SignOut, XCircle, ClipboardText, WarningCircle, Package, UserPlus, Check } from '@phosphor-icons/react';
import { ModalSessoes } from './ModalSessoes.jsx';

const C = {
  dark:    '#2d371b',
  olive:   '#434e2a',
  sec:     '#5a6642',
  muted:   '#8a9475',
  card:    '#f4f6ee',
  surface: '#eef1e6',
  white:   '#ffffff',
  border:  'rgba(180,190,160,0.55)',
  amber:   '#92600a',
  green:   '#3a6642',
  red:     '#9b1c1c',
};

export function Header({ userPerfil, onLogout }) {
  const [showSessoesModal, setShowSessoesModal] = useState(false);
  const [showNotifPopover, setShowNotifPopover] = useState(false);
  const [notificacoes, setNotificacoes] = useState([
    { id: 'n1', titulo: 'Solicitação de Acesso Pendente', descricao: 'Cb João Silva solicitou vinculação à Seção de Almoxarifado.', horario: '10 min', lida: false, icon: UserPlus },
    { id: 'n2', titulo: 'Cautela Vencendo Hoje',           descricao: 'Lanterna tática Pro (Pat. 072640) sob resp. de Cb. Nunes.',  horario: '1h',     lida: false, icon: WarningCircle },
    { id: 'n3', titulo: 'Novo Material Cadastrado',        descricao: 'Rádio portátil TPH900 adicionado à carga da Seção.',         horario: 'Ontem',  lida: true,  icon: Package },
  ]);

  const naoLidas = notificacoes.filter(n => !n.lida).length;
  const isChefe = userPerfil?.nivel_acesso === 'Section Chief' || userPerfil?.nivel_acesso === 'Administrator';

  return (
    <>
      <header
        className="flex flex-wrap items-start justify-between gap-4 pb-6 mb-2"
        style={{ borderBottom: `1px solid ${C.border}` }}
      >
        {/* Identidade */}
        <div className="space-y-1 min-w-0">
          <p className="section-label">Sistema de Controle de Materiais</p>
          <h2 className="t-title-page truncate" style={{ color: C.dark }}>
            Olá, {userPerfil?.nome_guerra || userPerfil?.nome_completo || 'Militar'}
          </h2>
          {isChefe && (
            <span className="badge badge-green inline-flex mt-1">
              <ShieldCheck size={12} weight="fill" />
              Chefe — {userPerfil?.secao?.sigla || userPerfil?.secao_solicitada || 'Geral'}
            </span>
          )}
        </div>

        {/* Ações */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {/* Badge seção */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-full" style={{ background: C.card, border: `1px solid ${C.border}` }}>
            <span className="dot-live" />
            <span className="t-caption" style={{ color: C.dark }}>
              {userPerfil?.secao?.nome || userPerfil?.secao_solicitada || 'SEÇÃO DE SUPRIMENTO'}
            </span>
          </div>

          {/* Sessões */}
          <button onClick={() => setShowSessoesModal(true)} className="btn btn-secondary btn-icon" title="Sessões">
            <Devices size={18} weight="duotone" color={C.sec} />
          </button>

          {/* Notificações */}
          <div className="relative">
            <button
              onClick={() => setShowNotifPopover(!showNotifPopover)}
              className="btn btn-secondary btn-icon relative"
              title="Notificações"
            >
              <Bell size={18} weight="duotone" color={C.sec} />
              {naoLidas > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-white border-2"
                  style={{ background: C.amber, fontSize: 10, fontWeight: 700, borderColor: C.surface }}>
                  {naoLidas}
                </span>
              )}
            </button>

            <AnimatePresence>
              {showNotifPopover && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.96 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 top-full mt-2 w-80 sm:w-96 card z-50"
                  style={{ padding: 16 }}
                >
                  <div className="flex items-center justify-between pb-3 mb-3" style={{ borderBottom: `1px solid ${C.border}` }}>
                    <div className="flex items-center gap-2">
                      <Bell size={16} weight="bold" color={C.sec} />
                      <span className="t-body-strong" style={{ color: C.dark }}>Notificações</span>
                    </div>
                    {naoLidas > 0 && (
                      <button onClick={() => setNotificacoes(prev => prev.map(n => ({ ...n, lida: true })))}
                        className="t-caption" style={{ color: C.sec }}>
                        <Check size={12} style={{ display: 'inline', marginRight: 3 }} />
                        Marcar lidas
                      </button>
                    )}
                  </div>

                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {notificacoes.length === 0 ? (
                      <p className="t-caption text-center py-6" style={{ color: C.muted }}>Nenhuma notificação.</p>
                    ) : notificacoes.map((n) => {
                      const Icon = n.icon;
                      return (
                        <div key={n.id} className="card-row" style={{ opacity: n.lida ? 0.6 : 1 }}>
                          <div className="icon-box icon-box-sm flex-shrink-0"
                            style={{ background: n.lida ? C.surface : '#fef3c7' }}>
                            <Icon size={14} color={n.lida ? C.muted : C.amber} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <span className="t-caption" style={{ fontWeight: 600, color: C.dark, lineHeight: 1.4 }}>{n.titulo}</span>
                              <span className="t-label" style={{ color: C.muted, flexShrink: 0 }}>{n.horario}</span>
                            </div>
                            <p className="t-label" style={{ color: C.muted, textTransform: 'none', letterSpacing: 0, marginTop: 2 }}>{n.descricao}</p>
                          </div>
                          <button onClick={() => setNotificacoes(prev => prev.filter(x => x.id !== n.id))}
                            style={{ color: C.muted, flexShrink: 0 }}>
                            <XCircle size={14} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Logout mobile */}
          <button onClick={onLogout} className="md:hidden btn btn-danger btn-icon" title="Sair">
            <SignOut size={18} color={C.red} />
          </button>
        </div>
      </header>

      {showSessoesModal && (
        <ModalSessoes userPerfil={userPerfil} onClose={() => setShowSessoesModal(false)} />
      )}
    </>
  );
}
