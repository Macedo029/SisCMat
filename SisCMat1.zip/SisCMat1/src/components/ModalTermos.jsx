import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, CheckCircle, XCircle, Scroll, ArrowDown } from '@phosphor-icons/react';

export function ModalTermos({ open, onClose, onAccept }) {
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);
  const scrollRef = useRef(null);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    if (scrollTop + clientHeight >= scrollHeight - 15) setHasScrolledToBottom(true);
  };

  if (!open) return null;

  const SECTIONS = [
    { title: '1. Objeto e Finalidade das Informações', body: 'O presente sistema tem por finalidade digitalizar e blindar a cadeia de custódia de suprimentos, armamentos e materiais sob responsabilidade da Organização Militar (OM). Todos os dados coletados (CPF, Nome de Guerra, Posto/Graduação, Imagens de Lacres e Fingerprints de Sessão) destinam-se exclusivamente ao controle patrimonial e prestação de contas funcional.' },
    { title: '2. Rastreabilidade e Imutabilidade de Auditoria (Código Penal Militar)', body: 'Ao solicitar acesso, o militar reconhece que todos os atos praticados no sistema serão gravados em log imutável. É vedada qualquer adulteração ou informação falsa, sujeito às sanções do Código Penal Militar (Decreto-Lei nº 1.001/1969) e do RDE (Decreto nº 4.346/2002).' },
    { title: '3. Proteção de Dados (LGPD Militar)', body: 'Em observância à Lei nº 13.709/2018 (LGPD), os dados cadastrais e registros operacionais não serão compartilhados com terceiros alheios à cadeia de comando da OM. O acesso às mídias é restrito às funções administrativas e fiscalizadoras.' },
    { title: '4. Fingerprint de Segurança e Dispositivos', body: 'Para segurança das sessões, o sistema registra o endereço IP, tipo de dispositivo, sistema operacional e navegador durante o login. O usuário poderá encerrar sessões ativas remotamente através do painel de dispositivos.' },
    { title: '5. Responsabilidade pela Guarda de Credenciais', body: 'O militar é integralmente responsável pela guarda de suas credenciais. O compartilhamento de credenciais com terceiros constitui infração disciplinar grave e poderá ensejar responsabilidade criminal nos termos da legislação vigente.' },
    { title: '6. Retenção e Descarte de Dados', body: 'Os registros do sistema serão mantidos pelo prazo mínimo de 5 (cinco) anos para fins de auditoria e passagem de comando, podendo ser estendido conforme normas internas da OM.' },
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.48)', backdropFilter: 'blur(6px)' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-2xl flex flex-col"
        style={{
          background: '#f4f6ee',
          border: '1px solid rgba(180,190,160,0.65)',
          borderRadius: 24,
          boxShadow: '0 20px 60px rgba(0,0,0,0.18)',
          maxHeight: '88vh',
          padding: 'clamp(20px,4vw,32px)',
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 flex-shrink-0" style={{ paddingBottom: 16, marginBottom: 0, borderBottom: '1px solid rgba(180,190,160,0.55)' }}>
          <div className="flex items-center gap-3 min-w-0">
            <div className="icon-box icon-box-md flex-shrink-0" style={{ background: '#434e2a', color: '#86efac' }}>
              <ShieldCheck size={22} weight="duotone" />
            </div>
            <div className="min-w-0">
              <h3 className="t-subtitle" style={{ color: '#2d371b' }}>Termos de Consentimento e Privacidade Militar</h3>
              <p className="t-caption" style={{ color: '#8a9475' }}>LGPD · Código Penal Militar · RDE</p>
            </div>
          </div>
          <button onClick={onClose} className="btn btn-ghost btn-icon flex-shrink-0">
            <XCircle size={20} color="#8a9475" />
          </button>
        </div>

        {/* Aviso de scroll */}
        {!hasScrolledToBottom && (
          <div className="feedback-banner feedback-warning flex-shrink-0" style={{ margin: '12px 0' }}>
            <Scroll size={16} className="flex-shrink-0" />
            <span className="t-caption flex-1">Role o documento até o final para habilitar o aceite.</span>
            <ArrowDown size={16} className="flex-shrink-0" style={{ animation: 'bounce 1s infinite' }} />
          </div>
        )}

        {/* Conteúdo com scroll */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto space-y-5"
          style={{
            margin: '12px 0',
            padding: 20,
            background: '#ffffff',
            borderRadius: 20,
            border: '1px solid rgba(180,190,160,0.55)',
          }}
        >
          <div style={{ paddingBottom: 12, marginBottom: 4, borderBottom: '1px solid rgba(180,190,160,0.45)' }}>
            <p className="t-label" style={{ color: '#8a9475' }}>Termo de Consentimento Livre e Esclarecido</p>
            <p className="t-body-strong" style={{ color: '#2d371b', marginTop: 4 }}>
              SisCMat — Sistema de Controle de Materiais e Cautela · Exército Brasileiro
            </p>
          </div>

          {SECTIONS.map((s, i) => (
            <section key={i} className="space-y-2">
              <p className="t-label" style={{ color: '#5a6642' }}>{s.title}</p>
              <p className="t-caption" style={{ color: '#5a6642', lineHeight: 1.65 }}>{s.body}</p>
            </section>
          ))}

          <div style={{ padding: 16, background: '#f4f6ee', borderRadius: 16, border: '1px solid rgba(180,190,160,0.55)' }}>
            <p className="t-caption" style={{ color: '#2d371b', fontWeight: 600 }}>
              Ao clicar em "Concordar e Aceitar", você declara ter lido integralmente este documento e aceita todas as condições de uso do SisCMat.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 flex-shrink-0" style={{ paddingTop: 16, borderTop: '1px solid rgba(180,190,160,0.55)' }}>
          <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
          <button
            type="button"
            disabled={!hasScrolledToBottom}
            onClick={() => { onAccept(); onClose(); }}
            className="btn btn-primary"
            style={!hasScrolledToBottom ? { opacity: 0.45, cursor: 'not-allowed' } : {}}
          >
            <CheckCircle size={16} weight="fill" />
            <span>Concordar e Aceitar</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
