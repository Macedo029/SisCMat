import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  IdentificationCard, 
  ShieldCheck, 
  Buildings, 
  UploadSimple, 
  LockKey, 
  CheckCircle, 
  WarningCircle, 
  SpinnerGap,
  Medal
} from '@phosphor-icons/react';
import { supabase, formatCPF, cleanCPF, cpfToEmail, uploadAvatar } from '../lib/supabaseClient.js';
import '../styles/neomorphism.css';

const POSTOS_GRADUACOES = [
  'Soldado', 'Cabo', 
  '3º Sgt', '2º Sgt', '1º Sgt', 'Subtenente',
  '2º Ten', '1º Ten', 'Capitão', 
  'Major', 'Tenente-Coronel', 'Coronel'
];

export function CadastroMilitar({ onSuccess, className = '' }) {
  const [formData, setFormData] = useState({
    cpf: '',
    nomeCompleto: '',
    nomeGuerra: '',
    postoGraduacao: 'Soldado',
    secaoId: '',
    nivelAcesso: 'Militar',
    senha: ''
  });

  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [secoes, setSecoes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  // Carregar seções disponíveis do Supabase
  useEffect(() => {
    async function loadSecoes() {
      try {
        const { data, error } = await supabase.from('secoes').select('id, nome, sigla').order('nome');
        if (!error && data && data.length > 0) {
          setSecoes(data);
          setFormData(prev => ({ ...prev, secaoId: data[0].id }));
        } else {
          // Fallback para visualização imediata se DB estiver em ajuste
          const fallbackSecoes = [
            { id: '11111111-1111-1111-1111-111111111111', nome: 'Reserva de Armas - 1ª Cia', sigla: 'ARMAS-1CIA' },
            { id: '22222222-2222-2222-2222-222222222222', nome: 'Almoxarifado Geral', sigla: 'ALMOX-GERAL' },
            { id: '33333333-3333-3333-3333-333333333333', nome: 'Comunicações & Eletrônica', sigla: 'PEL-COM' }
          ];
          setSecoes(fallbackSecoes);
          setFormData(prev => ({ ...prev, secaoId: fallbackSecoes[0].id }));
        }
      } catch (err) {
        console.warn('Usando seções fallback:', err);
      }
    }
    loadSecoes();
  }, []);

  const handleCPFChange = (e) => {
    const masked = formatCPF(e.target.value);
    setFormData(prev => ({ ...prev, cpf: masked }));
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFeedback(null);
    const cleanedCPF = cleanCPF(formData.cpf);

    if (cleanedCPF.length !== 11) {
      setFeedback({ type: 'error', message: 'Por favor, informe um CPF válido com 11 dígitos.' });
      return;
    }

    if (!formData.nomeCompleto || !formData.nomeGuerra || !formData.senha) {
      setFeedback({ type: 'error', message: 'Preencha todos os campos obrigatórios para o cadastro.' });
      return;
    }

    setLoading(true);

    try {
      // 1. Criar usuário de autenticação no Supabase via email sintético de CPF
      const syntheticEmail = cpfToEmail(cleanedCPF);
      
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: syntheticEmail,
        password: formData.senha,
        options: {
          data: {
            nome_completo: formData.nomeCompleto,
            cpf: formData.cpf
          }
        }
      });

      if (authError) {
        throw new Error(authError.message);
      }

      const userId = authData.user?.id;
      let avatarUrl = null;

      // 2. Upload de avatar (se fornecido)
      if (avatarFile && userId) {
        try {
          avatarUrl = await uploadAvatar(avatarFile, userId);
        } catch (uploadErr) {
          console.warn('Aviso: falha no upload da foto de perfil, prosseguindo com cadastro:', uploadErr);
        }
      }

      // 3. Criar ou atualizar registro na tabela 'perfis'
      if (userId) {
        const { error: profileError } = await supabase
          .from('perfis')
          .upsert({
            id: userId,
            cpf: formData.cpf,
            nome_completo: formData.nomeCompleto,
            nome_guerra: formData.nomeGuerra,
            posto_graduacao: formData.postoGraduacao,
            secao_id: formData.secaoId,
            nivel_acesso: formData.nivelAcesso,
            avatar_url: avatarUrl,
            ativo: true
          });

        if (profileError) {
          console.error('Erro ao registrar perfil militar:', profileError);
        }
      }

      setFeedback({
        type: 'success',
        message: `Militar ${formData.postoGraduacao} ${formData.nomeGuerra} cadastrado com sucesso!`
      });

      // Limpar formulário
      setFormData({
        cpf: '',
        nomeCompleto: '',
        nomeGuerra: '',
        postoGraduacao: 'Soldado',
        secaoId: secoes[0]?.id || '',
        nivelAcesso: 'Militar',
        senha: ''
      });
      setAvatarFile(null);
      setAvatarPreview(null);

      if (onSuccess) onSuccess();

    } catch (err) {
      console.error('Erro no cadastro:', err);
      setFeedback({ type: 'error', message: err.message || 'Falha ao registrar militar no sistema.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      className={`neo-card antigravity-float ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      style={{ maxWidth: '640px', width: '100%', margin: '0 auto' }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '24px' }}>
        <div style={{
          width: '48px',
          height: '48px',
          borderRadius: '16px',
          background: 'rgba(59, 130, 246, 0.15)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--primary-blue)',
          border: '1px solid rgba(59, 130, 246, 0.3)'
        }}>
          <ShieldCheck size={28} weight="duotone" />
        </div>
        <div>
          <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 700, color: 'var(--text-main)' }}>
            Cadastro de Militar
          </h2>
          <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: 'var(--text-muted)' }}>
            SisCMat — Sistema de Controle e Cautela Militar
          </p>
        </div>
      </div>

      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            style={{
              padding: '12px 16px',
              borderRadius: '16px',
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              fontSize: '14px',
              background: feedback.type === 'success' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
              border: `1px solid ${feedback.type === 'success' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
              color: feedback.type === 'success' ? 'var(--accent-tactical)' : 'var(--accent-danger)'
            }}
          >
            {feedback.type === 'success' ? <CheckCircle size={20} weight="bold" /> : <WarningCircle size={20} weight="bold" />}
            <span>{feedback.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit}>
        {/* Foto de Perfil Upload */}
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '24px' }}>
          <label style={{ cursor: 'pointer', textAlign: 'center' }}>
            <div style={{
              width: '90px',
              height: '90px',
              borderRadius: '24px',
              background: avatarPreview ? `url(${avatarPreview}) center/cover` : 'var(--bg-input)',
              border: 'var(--border-neomorph)',
              boxShadow: 'var(--shadow-inset)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-muted)',
              overflow: 'hidden',
              position: 'relative'
            }}>
              {!avatarPreview && (
                <>
                  <UploadSimple size={24} weight="regular" />
                  <span style={{ fontSize: '11px', marginTop: '4px' }}>Foto Perfil</span>
                </>
              )}
            </div>
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleAvatarChange} 
              style={{ display: 'none' }} 
            />
          </label>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px' }}>
          {/* CPF */}
          <div className="neo-input-group">
            <label className="neo-label">
              <IdentificationCard size={18} weight="duotone" /> CPF do Militar
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><IdentificationCard size={20} /></div>
              <input
                type="text"
                className="neo-input"
                placeholder="000.000.000-00"
                value={formData.cpf}
                onChange={handleCPFChange}
                maxLength={14}
                required
              />
            </div>
          </div>

          {/* Nome Completo */}
          <div className="neo-input-group">
            <label className="neo-label">
              <User size={18} weight="duotone" /> Nome Completo
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><User size={20} /></div>
              <input
                type="text"
                className="neo-input"
                placeholder="Ex: Carlos Eduardo da Silva"
                value={formData.nomeCompleto}
                onChange={(e) => setFormData(prev => ({ ...prev, nomeCompleto: e.target.value }))}
                required
              />
            </div>
          </div>

          {/* Nome de Guerra */}
          <div className="neo-input-group">
            <label className="neo-label">
              <Medal size={18} weight="duotone" /> Nome de Guerra
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><Medal size={20} /></div>
              <input
                type="text"
                className="neo-input"
                placeholder="Ex: C. Silva"
                value={formData.nomeGuerra}
                onChange={(e) => setFormData(prev => ({ ...prev, nomeGuerra: e.target.value }))}
                required
              />
            </div>
          </div>

          {/* Posto / Graduação */}
          <div className="neo-input-group">
            <label className="neo-label">
              <ShieldCheck size={18} weight="duotone" /> Posto / Graduação
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><ShieldCheck size={20} /></div>
              <select
                className="neo-select"
                value={formData.postoGraduacao}
                onChange={(e) => setFormData(prev => ({ ...prev, postoGraduacao: e.target.value }))}
              >
                {POSTOS_GRADUACOES.map(posto => (
                  <option key={posto} value={posto} style={{ background: '#0f172a', color: '#fff' }}>
                    {posto}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Seção Militar */}
          <div className="neo-input-group">
            <label className="neo-label">
              <Buildings size={18} weight="duotone" /> Seção de Lotação
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><Buildings size={20} /></div>
              <select
                className="neo-select"
                value={formData.secaoId}
                onChange={(e) => setFormData(prev => ({ ...prev, secaoId: e.target.value }))}
              >
                {secoes.map(secao => (
                  <option key={secao.id} value={secao.id} style={{ background: '#0f172a', color: '#fff' }}>
                    {secao.nome} ({secao.sigla})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Nível de Acesso */}
          <div className="neo-input-group">
            <label className="neo-label">
              <LockKey size={18} weight="duotone" /> Nível de Acesso (Privilégio)
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><LockKey size={20} /></div>
              <select
                className="neo-select"
                value={formData.nivelAcesso}
                onChange={(e) => setFormData(prev => ({ ...prev, nivelAcesso: e.target.value }))}
              >
                <option value="Militar" style={{ background: '#0f172a', color: '#fff' }}>Militar (Consulta / Solicitação)</option>
                <option value="Chefe de Seção" style={{ background: '#0f172a', color: '#fff' }}>Chefe de Seção (Reserva/Almoxarifado)</option>
                <option value="Administrador" style={{ background: '#0f172a', color: '#fff' }}>Administrador (Acesso Total OM)</option>
              </select>
            </div>
          </div>

          {/* Senha Inicial */}
          <div className="neo-input-group" style={{ gridColumn: '1 / -1' }}>
            <label className="neo-label">
              <LockKey size={18} weight="duotone" /> Senha de Acesso Inicial
            </label>
            <div className="neo-input-wrapper">
              <div className="neo-input-icon"><LockKey size={20} /></div>
              <input
                type="password"
                className="neo-input"
                placeholder="••••••••••••"
                value={formData.senha}
                onChange={(e) => setFormData(prev => ({ ...prev, senha: e.target.value }))}
                minLength={6}
                required
              />
            </div>
          </div>
        </div>

        <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'flex-end' }}>
          <button
            type="submit"
            className="neo-button neo-button-primary"
            disabled={loading}
            style={{ width: '100%', maxWidth: '280px' }}
          >
            {loading ? (
              <>
                <SpinnerGap size={20} className="antigravity-float" style={{ animationDuration: '1s' }} />
                <span>Registrando...</span>
              </>
            ) : (
              <>
                <ShieldCheck size={20} weight="bold" />
                <span>Cadastrar Militar</span>
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
}
