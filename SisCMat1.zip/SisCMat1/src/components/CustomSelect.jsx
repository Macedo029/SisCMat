import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CaretDown, Check } from '@phosphor-icons/react';

export function CustomSelect({ options = [], value, onChange, placeholder = 'Selecione...', icon: Icon, className = '' }) {
  const [open, setOpen] = useState(false);
  const containerRef = React.useRef(null);

  const selectedOption = options.find(opt => typeof opt === 'string' ? opt === value : opt.value === value);
  const getLabel = (opt) => { if (!opt) return placeholder; return typeof opt === 'string' ? opt : opt.label; };
  const getValue = (opt) => (typeof opt === 'string' ? opt : opt.value);

  React.useEffect(() => {
    const fn = (e) => { if (containerRef.current && !containerRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  }, []);

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="field-input flex items-center justify-between cursor-pointer"
        style={{ textAlign: 'left' }}
      >
        <div className="flex items-center gap-2 truncate overflow-hidden">
          {Icon && <Icon size={15} color="#8a9475" style={{ flexShrink: 0 }} />}
          <span style={{ color: selectedOption ? '#2d371b' : '#8a9475', fontWeight: selectedOption ? 500 : 400 }} className="truncate">
            {getLabel(selectedOption)}
          </span>
        </div>
        <CaretDown size={14} color="#8a9475" style={{ flexShrink: 0, transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.98 }}
            animate={{ opacity: 1, y: 4, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 z-50 max-h-56 overflow-y-auto p-1.5 space-y-0.5"
            style={{ background: '#f4f6ee', border: '1px solid rgba(180,190,160,0.65)', borderRadius: 18, boxShadow: '0 12px 40px rgba(0,0,0,0.14)' }}
          >
            {options.map((opt, idx) => {
              const optVal = getValue(opt);
              const optLabel = getLabel(opt);
              const isSelected = optVal === value;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => { onChange(optVal); setOpen(false); }}
                  className="w-full text-left flex items-center justify-between"
                  style={{
                    padding: '9px 14px',
                    borderRadius: 14,
                    fontSize: 13,
                    fontWeight: 500,
                    background: isSelected ? '#434e2a' : 'transparent',
                    color: isSelected ? '#f4f6ee' : '#2d371b',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'background 0.15s',
                  }}
                  onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = 'rgba(67,78,42,0.08)'; }}
                  onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
                >
                  <span className="truncate">{optLabel}</span>
                  {isSelected && <Check size={13} weight="bold" style={{ flexShrink: 0 }} />}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
