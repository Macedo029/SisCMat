import React from 'react';
import { CadastroMilitar } from '../components/CadastroMilitar.jsx';
import { UploadFotosLacres } from '../components/UploadFotosLacres.jsx';
import '../styles/neomorphism.css';

/**
 * FRAMER CODE OVERRIDES & CODE COMPONENTS - SisCMat
 * 
 * Como utilizar no Framer:
 * 1. Crie um arquivo de Code Override no seu projeto Framer.
 * 2. Copie e cole as funções abaixo.
 * 3. Selecione qualquer Frame na tela visual do Framer e aplique o Override correspondente.
 */

// 1. Componente Framer pronto para Cadastro Militar
export function FramerCadastroMilitar(props) {
  return <CadastroMilitar {...props} />;
}

// 2. Componente Framer pronto para Upload em Lote de Lacres
export function FramerUploadFotosLacres(props) {
  return <UploadFotosLacres {...props} />;
}

// 3. Override de Estilo Antigravity & Soft-Neomorphism para qualquer Frame do Framer
export function withNeomorphicCard(Component) {
  return (props) => {
    return (
      <div className="neo-card antigravity-float" style={{ width: '100%', height: '100%' }}>
        <Component {...props} />
      </div>
    );
  };
}

// 4. Override de Controle de Acesso Militar (Visibilidade baseada no nível de acesso do usuário)
export function withAccessControl(Component) {
  return (props) => {
    // Exemplo de verificação de permissão no Framer
    const requiredLevel = props.requiredLevel || 'Chefe de Seção';
    const userLevel = localStorage.getItem('siscmat_user_nivel') || 'Militar';

    const hasAccess = 
      userLevel === 'Administrador' ||
      (userLevel === 'Chefe de Seção' && requiredLevel !== 'Administrador') ||
      (userLevel === requiredLevel);

    if (!hasAccess) {
      return (
        <div className="neo-card" style={{ padding: '20px', textAlign: 'center', color: 'var(--accent-warning)' }}>
          Acesso restrito ao nível: <strong>{requiredLevel}</strong>
        </div>
      );
    }

    return <Component {...props} />;
  };
}
