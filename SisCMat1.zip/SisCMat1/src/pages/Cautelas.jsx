import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ClipboardText, Check, Clock, WarningCircle, Seal, Plus, X, SpinnerGap, Package, MagnifyingGlass } from '@phosphor-icons/react';
import { Header } from '../components/Header.jsx';
import { supabase, buscarMilitaresParaCautela, verificarExpedienteSecao, uploadFotosLacre } from '../lib/supabaseClient.js';

export function Cautelas({ userPerfil, onLogout }) {
  const [activeTab, setActiveTab]   = useState('ativas');
  const [cautelas, setCautelas]     = useState([]);
  const [historico, setHistorico]   = useState([]);
  const [showModalNova, setShowModalNova] = useState(false);
  const [materiaisDisponiveis, setMateriaisDisponiveis] = useState([]);
  const [selectedMaterialId, setSelectedMaterialId] = useState('');
  const [militarSearch, setMilitarSearch]   = useState('');
  const [militaresResultados, setMilitaresResultados] = useState([]);
  const [selectedMilitar, setSelectedMilitar] = useState(null);
  const [lacreSaida, setLacreSaida]       = useState('');
  const [expediente, setExpediente]       = useState({ aberto: true });
  const [motivoExcecao, setMotivoExcecao] = useState('');
  const [fotosEntregaFiles, setFotosEntregaFiles] = useState([]);
  const [fotosEntregaPreviews, setFotosEntregaPreviews] = useState([]);
  const [encerrarTarget, setEncerrarTarget] = useState(null);
  const [lacreRetorno, setLacreRetorno]     = useState('');
  const [observacoesRetorno, setObservacoesRetorno] = useState('');
  const [fotosDevolucaoFiles, setFotosDevolucaoFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        const { data: mats } = await supabase.from('materiais').select('*').eq('status_disponibilidade','disponivel');
        setMateriaisDisponiveis(mats?.length ? mats : [
          { id:'mat-1', nome:'Rádio portátil TPH900', numero_patrimonio:'084317' },
          { id:'mat-2', nome:'Lanterna tática Pro',   numero_patrimonio:'072640' },
        ]);
      } catch {}
      if (userPerfil?.secao_id) {
        try { const exp = await verificarExpedienteSecao(userPerfil.secao_id); setExpediente(exp); } catch {}
      }
      setCautelas([
        { id:'c1', material_nome:'Rádio portátil TPH900', requerente_nome:'Sd. Alves Martins',  data_retirada:'02 out 2026 · 09:42', numero_patrimonio:'084317', foto_url:'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=600&q=80', lacre_saida:'19A-004' },
        { id:'c2', material_nome:'Lanterna tática Pro',   requerente_nome:'Cb. Nunes Pereira', data_retirada:'01 out 2026 · 16:20', numero_patrimonio:'072640', foto_url:'https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?auto=format&fit=crop&w=600&q=80', lacre_saida:'21B-012' },
      ]);
      setHistorico([
        { id:'h1', texto:'Rádio portátil TPH900 · Devolvido por Sd. Alves · 28 set 2026' },
        { id:'h2', texto:'Lanterna tática Pro · Devolvido por Cb. Nunes · 24 set 2026' },
        { id:'h3', texto:'Kit de ferramentas · Devolvido por Sgt. Lima · 20 set 2026' },
      ]);
    }
    loadData();
  }, [userPerfil]);

  const handleMilitarSearch = async (e) => {
    const q = e.target.value;
    setMilitarSearch(q);
    if (q.trim()) { const r = await buscarMilitaresParaCautela(q, userPerfil?.secao_id); setMilitaresResultados(r); }
    else setMilitaresResultados([]);
  };

  const handleCriarCautela = async (e) => {
    e.preventDefault();
    setFeedback(null);
    if (!selectedMaterialId || !selectedMilitar || !lacreSaida) { setFeedback({ type:'error', message:'Selecione o material, o militar e informe o lacre de saída.' }); return; }
    if (!expediente.aberto && !motivoExcecao.trim()) { setFeedback({ type:'error', message:'Expediente encerrado. Informe o motivo da exceção.' }); return; }
    setLoading(true);
    try {
      const mat = materiaisDisponiveis.find(m => m.id === selectedMaterialId);
      const id  = `caut_${Date.now()}`;
      if (fotosEntregaFiles.length > 0) await uploadFotosLacre(fotosEntregaFiles, id, 'entrega').catch(() => {});
      setCautelas(prev => [{ id, material_nome: mat?.nome || 'Material', requerente_nome: `${selectedMilitar.posto_graduacao} ${selectedMilitar.nome_guerra}`, data_retirada: new Date().toLocaleString('pt-BR'), numero_patrimonio: mat?.numero_patrimonio || '', foto_url: mat?.foto_capa_url || '', lacre_saida: lacreSaida }, ...prev]);
      setShowModalNova(false); setSelectedMaterialId(''); setSelectedMilitar(null); setMilitarSearch(''); setLacreSaida(''); setMotivoExcecao(''); setFotosEntregaFiles([]); setFotosEntregaPreviews([]);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleEncerrar = async (e) => {
    e.preventDefault();
    if (!lacreRetorno) return;
    setLoading(true);
    try {
      if (fotosDevolucaoFiles.length > 0) await uploadFotosLacre(fotosDevolucaoFiles, encerrarTarget.id, 'devolucao').catch(() => {});
      setCautelas(prev => prev.filter(c => c.id !== encerrarTarget.id));
      setHistorico(prev => [{ id:`h_${Date.now()}`, texto:`${encerrarTarget.material_nome} · Devolvido por ${encerrarTarget.requerente_nome} · Lacre: ${lacreRetorno} · ${new Date().toLocaleString('pt-BR')}` }, ...prev]);
      setEncerrarTarget(null); setLacreRetorno(''); setObservacoesRetorno(''); setFotosDevolucaoFiles([]);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const modalStyle = { background:'#f4f6ee', border:'1px solid rgba(180,190,160,0.65)', borderRadius:24, boxShadow:'0 20px 60px rgba(0,0,0,0.18)', width:'100%', maxWidth:520, padding:28, maxHeight:'90vh', overflowY:'auto' };
  const inp = (props) => <input {...props} className="field-input" />;

  return (
    <div className="page-wrapper space-y-6">
      <Header userPerfil={userPerfil} onLogout={onLogout} />

      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="t-title-page" style={{ color:'#2d371b' }}>Painel de cautelas</h2>
          <p className="t-caption" style={{ color:'#8a9475', marginTop:4 }}>Acompanhe retiradas, devoluções e o histórico de movimentações.</p>
        </div>
        <button onClick={() => setShowModalNova(true)} className="btn btn-primary">
          <Plus size={16} weight="bold" /><span>Nova cautela</span>
        </button>
      </div>

      <AnimatePresence>
        {feedback && (
          <motion.div initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }}>
            <div className={`feedback-banner ${feedback.type === 'error' ? 'feedback-error' : 'feedback-success'}`}>
              <WarningCircle size={16} style={{ flexShrink:0 }} />
              <span className="t-caption">{feedback.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Abas */}
      <div className="tab-bar" style={{ width: 'fit-content' }}>
        <button onClick={() => setActiveTab('ativas')} className={`tab-item ${activeTab === 'ativas' ? 'active' : ''}`}>
          <ClipboardText size={14} /><span>Cautelas ativas · {cautelas.length}</span>
        </button>
        <button onClick={() => setActiveTab('historico')} className={`tab-item ${activeTab === 'historico' ? 'active' : ''}`}>
          <Clock size={14} /><span>Histórico</span>
        </button>
      </div>

      {/* Aba ativas */}
      {activeTab === 'ativas' && (
        <motion.section initial={{ opacity:0 }} animate={{ opacity:1 }} className="card space-y-4">
          <div className="flex items-center justify-between pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
            <p className="t-body-strong" style={{ color:'#2d371b' }}>Cautelas ativas</p>
            <span className="t-caption" style={{ color:'#8a9475' }}>{cautelas.length} registros</span>
          </div>
          <div className="space-y-3">
            {cautelas.map(c => (
              <div key={c.id} className="card-row flex-wrap gap-3">
                {c.foto_url && <img src={c.foto_url} alt={c.material_nome} style={{ width:56, height:56, borderRadius:14, objectFit:'cover', border:'1px solid rgba(180,190,160,0.55)', flexShrink:0 }} />}
                <div style={{ flex:1, minWidth:140 }}>
                  <p className="t-body-strong" style={{ color:'#2d371b' }}>{c.material_nome}</p>
                  <p className="t-caption" style={{ color:'#8a9475', marginTop:2 }}>Requerente: <span style={{ fontWeight:600, color:'#5a6642' }}>{c.requerente_nome}</span></p>
                  <p className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0, marginTop:2 }}>{c.data_retirada}</p>
                  <p className="t-label" style={{ color:'#5a6642', textTransform:'none', letterSpacing:0, fontFamily:'monospace', marginTop:2 }}>Pat. {c.numero_patrimonio} · Lacre {c.lacre_saida}</p>
                </div>
                <button onClick={() => setEncerrarTarget(c)} className="btn btn-primary btn-sm" style={{ flexShrink:0 }}>
                  <Check size={14} weight="bold" /><span>Encerrar</span>
                </button>
              </div>
            ))}
            {!cautelas.length && <p className="t-caption text-center py-6" style={{ color:'#8a9475' }}>Nenhuma cautela ativa no momento.</p>}
          </div>
        </motion.section>
      )}

      {/* Aba histórico */}
      {activeTab === 'historico' && (
        <motion.section initial={{ opacity:0 }} animate={{ opacity:1 }} className="card space-y-4">
          <div className="pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
            <p className="t-body-strong" style={{ color:'#2d371b' }}>Histórico geral</p>
            <p className="t-caption" style={{ color:'#8a9475', marginTop:4 }}>Registros preservados para auditoria permanente.</p>
          </div>
          <div style={{ borderTop:'1px solid rgba(180,190,160,0.45)' }}>
            {historico.map(h => (
              <div key={h.id} className="flex items-center gap-3 py-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.35)' }}>
                <Package size={15} color="#8a9475" style={{ flexShrink:0 }} />
                <span className="t-caption" style={{ color:'#5a6642' }}>{h.texto}</span>
              </div>
            ))}
          </div>
        </motion.section>
      )}

      {/* Modal Nova Cautela */}
      <AnimatePresence>
        {showModalNova && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background:'rgba(0,0,0,0.42)', backdropFilter:'blur(6px)' }}>
            <motion.div initial={{ opacity:0, scale:0.96 }} animate={{ opacity:1, scale:1 }} exit={{ opacity:0, scale:0.96 }} style={modalStyle}>
              <div className="flex items-center justify-between pb-4 mb-4" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
                <h3 className="t-subtitle" style={{ color:'#2d371b' }}>Abrir Nova Cautela</h3>
                <button onClick={() => setShowModalNova(false)} className="btn btn-ghost btn-icon"><X size={18} color="#8a9475" /></button>
              </div>

              {!expediente.aberto && (
                <div className="feedback-banner feedback-warning mb-4">
                  <WarningCircle size={16} style={{ flexShrink:0 }} />
                  <div>
                    <p className="t-label" style={{ marginBottom:4 }}>Exceção Fora de Expediente</p>
                    <p className="t-caption">{expediente.mensagem}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleCriarCautela} className="space-y-4">
                <div className="field-group">
                  <label className="field-label">Material</label>
                  <select value={selectedMaterialId} onChange={e => setSelectedMaterialId(e.target.value)} className="field-input" required>
                    <option value="">— Escolha o item em estoque —</option>
                    {materiaisDisponiveis.map(m => <option key={m.id} value={m.id}>{m.nome} (Pat. {m.numero_patrimonio})</option>)}
                  </select>
                </div>

                <div className="field-group" style={{ position:'relative' }}>
                  <label className="field-label">Para quem será cautelado?</label>
                  <div style={{ position:'relative' }}>
                    <MagnifyingGlass size={15} color="#8a9475" style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', pointerEvents:'none' }} />
                    {inp({ type:'text', placeholder:'Posto ou Nome (SGT, TEN, Cb...)', value:militarSearch, onChange:handleMilitarSearch, style:{ paddingLeft:40 }, required:true })}
                  </div>
                  {militaresResultados.length > 0 && (
                    <div style={{ position:'absolute', top:'100%', left:0, right:0, zIndex:20, marginTop:4, maxHeight:160, overflowY:'auto', background:'#ffffff', border:'1px solid rgba(180,190,160,0.65)', borderRadius:16, boxShadow:'0 8px 30px rgba(0,0,0,0.12)' }}>
                      {militaresResultados.map(m => (
                        <button key={m.id} type="button" onClick={() => { setSelectedMilitar(m); setMilitarSearch(`${m.posto_graduacao} ${m.nome_guerra}`); setMilitaresResultados([]); }}
                          className="w-full flex items-center justify-between" style={{ padding:'10px 16px', background:'transparent', border:'none', cursor:'pointer', borderBottom:'1px solid rgba(180,190,160,0.35)' }}>
                          <span className="t-caption" style={{ fontWeight:600, color:'#2d371b' }}>{m.posto_graduacao} {m.nome_guerra}</span>
                          <span className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0 }}>{m.secao?.sigla || 'Seção'}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="field-group">
                  <label className="field-label">Nº Lacre Físico de Saída</label>
                  {inp({ type:'text', placeholder:'Ex: LAC-2026-9031', value:lacreSaida, onChange:e => setLacreSaida(e.target.value), required:true })}
                </div>

                {!expediente.aberto && (
                  <div className="field-group">
                    <label className="field-label" style={{ color:'#92600a' }}>Motivo da Exceção</label>
                    <textarea placeholder="Justifique a necessidade fora do horário..." value={motivoExcecao} onChange={e => setMotivoExcecao(e.target.value)}
                      className="field-input" style={{ minHeight:70, resize:'none', borderColor:'#f59e0b' }} required />
                  </div>
                )}

                <div className="field-group">
                  <label className="field-label">Fotos de Vistoria (Opcional)</label>
                  <input type="file" accept="image/*" multiple onChange={e => { const f = Array.from(e.target.files); setFotosEntregaFiles(prev => [...prev, ...f]); setFotosEntregaPreviews(prev => [...prev, ...f.map(x => URL.createObjectURL(x))]); }}
                    className="t-caption" style={{ color:'#8a9475', width:'100%' }} />
                </div>

                {fotosEntregaPreviews.length > 0 && (
                  <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
                    {fotosEntregaPreviews.map((src,i) => <img key={i} src={src} alt="" style={{ height:56, borderRadius:12, objectFit:'cover', border:'1px solid rgba(180,190,160,0.55)' }} />)}
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2">
                  <button type="button" onClick={() => setShowModalNova(false)} className="btn btn-secondary">Cancelar</button>
                  <button type="submit" disabled={loading} className="btn btn-primary">
                    {loading ? <SpinnerGap size={15} className="animate-spin" /> : <Check size={15} />}
                    <span>Confirmar Cautela</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal Encerrar */}
      <AnimatePresence>
        {encerrarTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background:'rgba(0,0,0,0.42)', backdropFilter:'blur(6px)' }}>
            <motion.div initial={{ opacity:0, scale:0.96 }} animate={{ opacity:1, scale:1 }} exit={{ opacity:0, scale:0.96 }} style={modalStyle}>
              <div className="flex items-center justify-between pb-4 mb-4" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
                <h3 className="t-subtitle" style={{ color:'#2d371b' }}>Encerrar Cautela — Devolução</h3>
                <button onClick={() => setEncerrarTarget(null)} className="btn btn-ghost btn-icon"><X size={18} color="#8a9475" /></button>
              </div>
              <div className="card-row mb-4">
                <Package size={15} color="#8a9475" style={{ flexShrink:0 }} />
                <p className="t-caption" style={{ color:'#5a6642' }}>
                  <span style={{ fontWeight:600, color:'#2d371b' }}>{encerrarTarget.material_nome}</span>
                  {' '}· Devolvente: <span style={{ fontWeight:600 }}>{encerrarTarget.requerente_nome}</span>
                </p>
              </div>
              <form onSubmit={handleEncerrar} className="space-y-4">
                <div className="field-group">
                  <label className="field-label">Nº Lacre Físico de Retorno</label>
                  {inp({ type:'text', placeholder:'Ex: LAC-RET-8830', value:lacreRetorno, onChange:e => setLacreRetorno(e.target.value), required:true })}
                </div>
                <div className="field-group">
                  <label className="field-label">Observações de Conservação</label>
                  <textarea placeholder="Sem avarias, lacre conferido..." value={observacoesRetorno} onChange={e => setObservacoesRetorno(e.target.value)}
                    className="field-input" style={{ minHeight:70, resize:'none' }} />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button type="button" onClick={() => setEncerrarTarget(null)} className="btn btn-secondary">Cancelar</button>
                  <button type="submit" disabled={loading} className="btn btn-primary">
                    {loading ? <SpinnerGap size={15} className="animate-spin" /> : <Check size={15} />}
                    <span>Confirmar Devolução</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
