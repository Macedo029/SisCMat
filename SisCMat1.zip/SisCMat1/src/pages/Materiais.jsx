import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MagnifyingGlass, Funnel, QrCode, Plus, X, CheckCircle, Seal, SpinnerGap } from '@phosphor-icons/react';
import { Header } from '../components/Header.jsx';
import { supabase } from '../lib/supabaseClient.js';

const DEMO = [
  { id:'1', nome:'Rádio portátil TPH900', categoria:'COMUNICAÇÃO', quantidade_disponivel:14, quantidade_total:18, numero_patrimonio:'084317', numero_lacre_atual:'19A-004', origem:'3º B Log', foto_capa_url:'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=600&q=80' },
  { id:'2', nome:'Lanterna tática Pro',   categoria:'ILUMINAÇÃO',  quantidade_disponivel:18, quantidade_total:24, numero_patrimonio:'072640', numero_lacre_atual:'21B-012', origem:'2º B Log', foto_capa_url:'https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?auto=format&fit=crop&w=600&q=80' },
  { id:'3', nome:'Kit de ferramentas',    categoria:'MANUTENÇÃO',  quantidade_disponivel:7,  quantidade_total:10, numero_patrimonio:'051228', numero_lacre_atual:'18C-009', origem:'4º B Log', foto_capa_url:'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80' },
];

const INIT = { nome:'', descricao:'', categoria:'Comunicação', numeroPatrimonio:'', numeroLacreAtual:'', quantidadeTotal:1, estadoFisico:'Excelente estado de conservação', fotoCapaUrl:'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80' };

export function Materiais({ userPerfil, onLogout }) {
  const [materiais, setMateriais] = useState(DEMO);
  const [search, setSearch] = useState('');
  const [filtroLacre, setFiltroLacre] = useState(false);
  const [filtroPatrimonio, setFiltroPatrimonio] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [novoItem, setNovoItem] = useState(INIT);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from('materiais').select('*').order('created_at', { ascending: false })
      .then(({ data, error }) => { if (!error && data?.length) setMateriais(data); })
      .catch(() => {});
  }, []);

  const handleSalvar = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.from('materiais').insert({
        nome: novoItem.nome, descricao: novoItem.descricao, categoria: novoItem.categoria,
        numero_patrimonio: novoItem.numeroPatrimonio, numero_lacre_atual: novoItem.numeroLacreAtual,
        quantidade_total: parseInt(novoItem.quantidadeTotal), quantidade_disponivel: parseInt(novoItem.quantidadeTotal),
        secao_id: userPerfil?.secao_id || '11111111-1111-1111-1111-111111111111',
        estado_fisico: novoItem.estadoFisico, foto_capa_url: novoItem.fotoCapaUrl,
      }).select();
      if (!error && data) setMateriais(prev => [data[0], ...prev]);
      else setMateriais(prev => [{ id: Date.now().toString(), nome: novoItem.nome, categoria: novoItem.categoria.toUpperCase(), quantidade_disponivel: parseInt(novoItem.quantidadeTotal), quantidade_total: parseInt(novoItem.quantidadeTotal), numero_patrimonio: novoItem.numeroPatrimonio, numero_lacre_atual: novoItem.numeroLacreAtual, origem:'Seção Atual', foto_capa_url: novoItem.fotoCapaUrl }, ...prev]);
      setShowModal(false);
      setNovoItem(INIT);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const filtrados = materiais.filter(m => {
    const t = search.toLowerCase();
    if (filtroLacre && !m.numero_lacre_atual) return false;
    if (filtroPatrimonio && !m.numero_patrimonio) return false;
    return m.nome?.toLowerCase().includes(t) || m.numero_patrimonio?.toLowerCase().includes(t) || m.numero_lacre_atual?.toLowerCase().includes(t);
  });

  const filterBtn = (active, toggle, Icon, label) => (
    <button onClick={toggle} className={`btn btn-sm ${active ? 'btn-primary' : 'btn-secondary'}`}>
      <Icon size={14} />
      <span>{label}</span>
    </button>
  );

  const inp = (props) => <input {...props} className="field-input" />;

  return (
    <div className="page-wrapper space-y-6">
      <Header userPerfil={userPerfil} onLogout={onLogout} />

      <div>
        <h2 className="t-title-page" style={{ color: '#2d371b' }}>Catálogo de materiais</h2>
        <p className="t-caption" style={{ color: '#8a9475', marginTop: 4 }}>Consulte o acervo, disponibilidade e identificação patrimonial.</p>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div style={{ position: 'relative', flex: 1, minWidth: 240 }}>
          <MagnifyingGlass size={16} color="#8a9475" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
          <input type="text" placeholder="Buscar material, lacre ou patrimônio" value={search} onChange={e => setSearch(e.target.value)}
            className="field-input" style={{ paddingLeft: 40 }} />
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {filterBtn(filtroLacre,      () => setFiltroLacre(!filtroLacre),           Funnel, 'Lacre')}
          {filterBtn(filtroPatrimonio, () => setFiltroPatrimonio(!filtroPatrimonio), QrCode, 'Patrimônio')}
          <button onClick={() => setShowModal(true)} className="btn btn-primary btn-sm">
            <Plus size={15} weight="bold" /><span>Novo material</span>
          </button>
        </div>
      </div>

      {/* Grid de cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtrados.map(m => (
          <motion.div key={m.id} layout initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.2 }}
            className="card card-interactive" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {/* Foto */}
            <div style={{ position: 'relative', height: 180, overflow: 'hidden', background: '#1a2211', borderRadius: '24px 24px 0 0' }}>
              <img src={m.foto_capa_url} alt={m.nome} style={{ width:'100%', height:'100%', objectFit:'cover', transition:'transform 0.5s' }} />
              <span className="badge badge-green" style={{ position:'absolute', top:12, right:12, background:'rgba(58,102,66,0.88)', color:'#dcfce7', border:'none' }}>
                Disponível
              </span>
            </div>
            {/* Conteúdo */}
            <div style={{ padding: '16px 20px', flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div>
                <p className="section-label" style={{ marginBottom: 4 }}>{m.categoria}</p>
                <h3 className="t-subtitle" style={{ color: '#2d371b' }}>{m.nome}</h3>
              </div>
              <div className="flex items-center justify-between" style={{ paddingTop: 10, borderTop: '1px solid rgba(180,190,160,0.55)' }}>
                <span className="t-caption" style={{ color: '#8a9475' }}>Disponíveis</span>
                <span className="t-caption" style={{ color: '#2d371b', fontWeight: 600 }}>{m.quantidade_disponivel} de {m.quantidade_total} un.</span>
              </div>
              <div style={{ paddingTop: 10, borderTop: '1px solid rgba(180,190,160,0.55)', display: 'flex', flexDirection: 'column', gap: 5 }}>
                <div className="flex items-center gap-1.5">
                  <QrCode size={12} color="#8a9475" />
                  <span className="t-caption" style={{ color: '#8a9475' }}>Pat. <span style={{ fontFamily: 'monospace', fontWeight: 600, color: '#2d371b' }}>{m.numero_patrimonio}</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Seal size={12} color="#8a9475" />
                  <span className="t-caption" style={{ color: '#8a9475' }}>Lacre <span style={{ fontFamily: 'monospace', fontWeight: 600, color: '#2d371b' }}>{m.numero_lacre_atual || 'S/N'}</span></span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.42)', backdropFilter: 'blur(6px)' }}>
            <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }}
              style={{ background: '#f4f6ee', border: '1px solid rgba(180,190,160,0.65)', borderRadius: 24, boxShadow: '0 20px 60px rgba(0,0,0,0.18)', width: '100%', maxWidth: 500, padding: 28, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="flex items-center justify-between pb-4 mb-4" style={{ borderBottom: '1px solid rgba(180,190,160,0.55)' }}>
                <h3 className="t-subtitle" style={{ color: '#2d371b' }}>Cadastrar Novo Material</h3>
                <button onClick={() => setShowModal(false)} className="btn btn-ghost btn-icon"><X size={18} color="#8a9475" /></button>
              </div>
              <form onSubmit={handleSalvar} className="space-y-4">
                <div className="field-group"><label className="field-label">Nome do Item</label>{inp({ type:'text', placeholder:'Ex: Rádio portátil TPH900', value: novoItem.nome, onChange: e => setNovoItem(p => ({...p, nome: e.target.value})), required: true })}</div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="field-group"><label className="field-label">Nº Patrimônio</label>{inp({ type:'text', placeholder:'Ex: 084317', value: novoItem.numeroPatrimonio, onChange: e => setNovoItem(p => ({...p, numeroPatrimonio: e.target.value})), required: true })}</div>
                  <div className="field-group"><label className="field-label">Nº Lacre</label>{inp({ type:'text', placeholder:'Ex: 19A-004', value: novoItem.numeroLacreAtual, onChange: e => setNovoItem(p => ({...p, numeroLacreAtual: e.target.value})), required: true })}</div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="field-group">
                    <label className="field-label">Categoria</label>
                    <select value={novoItem.categoria} onChange={e => setNovoItem(p => ({...p, categoria: e.target.value}))} className="field-input">
                      {['Comunicação','Iluminação','Ferramentas','Armamento','Óptica tática'].map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                  <div className="field-group"><label className="field-label">Quantidade</label>{inp({ type:'number', min:1, value: novoItem.quantidadeTotal, onChange: e => setNovoItem(p => ({...p, quantidadeTotal: e.target.value})), required: true })}</div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button type="button" onClick={() => setShowModal(false)} className="btn btn-secondary">Cancelar</button>
                  <button type="submit" disabled={loading} className="btn btn-primary">
                    {loading ? <SpinnerGap size={15} className="animate-spin" /> : <CheckCircle size={15} />}
                    <span>Salvar Material</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
