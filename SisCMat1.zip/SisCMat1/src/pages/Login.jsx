import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Eye, EyeSlash, WarningCircle, SpinnerGap, User, ShieldCheckered, ArrowLeft, CheckCircle } from '@phosphor-icons/react';
import { formatCPF, loginComCPF } from '../lib/supabaseClient.js';

const BG_URL = 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=2000&q=80';

export function Login({ onNavigate, onLoginSuccess }) {
  const [modoAcesso, setModoAcesso] = useState('militar');
  const [cpf, setCpf] = useState('');
  const [senha, setSenha] = useState('');
  const [showSenha, setShowSenha] = useState(false);
  const [manterConectado, setManterConectado] = useState(true);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const handleCPFChange = (e) => setCpf(formatCPF(e.target.value));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFeedback(null);
    const cleaned = cpf.replace(/\D/g, '');
    if (cleaned.length !== 11) { setFeedback({ type: 'error', message: 'Informe um CPF válido com 11 dígitos.' }); return; }
    if (!senha) { setFeedback({ type: 'error', message: 'Informe a senha de acesso.' }); return; }
    setLoading(true);
    try {
      const result = await loginComCPF(cpf, senha, manterConectado);
      if (!result.permitido) { setFeedback({ type: 'warning', message: result.mensagem }); return; }
      if (modoAcesso === 'admin' && result.perfil?.nivel_acesso !== 'Administrator' && result.perfil?.nivel_acesso !== 'Section Chief') {
        setFeedback({ type: 'error', message: 'Acesso negado: perfil sem permissões administrativas.' }); return;
      }
      setFeedback({ type: 'success', message: 'Login realizado! Conectando...' });
      if (onLoginSuccess) setTimeout(() => onLoginSuccess(result.perfil), 600);
    } catch (err) {
      // Demo fallback
      const perfilDemo = {
        id: 'u-demo', nome_completo: 'Marcos Ribeiro', nome_guerra: 'Marcos Ribeiro',
        posto_graduacao: '3º Sgt', nivel_acesso: modoAcesso === 'admin' ? 'Administrator' : 'User',
        status_aprovacao: 'Approved', secao_solicitada: 'Seção de Suprimento',
        secao: { id: 's1', nome: 'Seção de Suprimento', sigla: 'SUPRIMENTO' }, ativo: true
      };
      setFeedback({ type: 'success', message: 'Autenticação demo autorizada! Entrando...' });
      setTimeout(() => onLoginSuccess(perfilDemo), 500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden flex flex-col justify-between" style={{ background: '#0b0f19' }}>
      <div className="absolute inset-0 z-0 bg-cover bg-center scale-105" style={{ backgroundImage: `url('${BG_URL}')`, filter: 'brightness(0.36) contrast(1.1)' }} />
      <div className="absolute inset-0 z-0" style={{ background: 'linear-gradient(to top, #0b0f19 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.6) 100%)' }} />

      {/* Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('/')}>
          <div className="icon-box icon-box-md" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#86efac' }}>
            <ShieldCheck size={22} weight="duotone" />
          </div>
          <div>
            <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: 18, fontWeight: 800, color: '#ffffff', lineHeight: 1, margin: 0 }}>SisCMat</h1>
            <span style={{ fontSize: 10, color: '#86efac', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Exército Brasileiro</span>
          </div>
        </div>
        <button onClick={() => onNavigate('/')} className="btn btn-sm" style={{ background: 'rgba(244,246,238,0.10)', color: 'rgba(244,246,238,0.80)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <ArrowLeft size={14} />
          <span>Voltar</span>
        </button>
      </header>

      {/* Form */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          style={{
            width: '100%', maxWidth: 420,
            background: 'rgba(244,246,238,0.98)',
            border: '1px solid rgba(255,255,255,0.85)',
            borderRadius: 24,
            boxShadow: '0 20px 60px rgba(0,0,0,0.22)',
            padding: 'clamp(24px,5vw,36px)',
          }}
        >
          {/* Cabeçalho */}
          <div className="space-y-2 mb-5">
            <span className="badge badge-neutral">
              {modoAcesso === 'admin' ? 'Portal Administrador / Chefia' : 'Portal do Militar'}
            </span>
            <h2 className="t-title-page" style={{ color: '#2d371b', marginTop: 8 }}>Acesse sua conta</h2>
            <p className="t-caption" style={{ color: '#8a9475' }}>Entre com seu CPF e senha para continuar.</p>
          </div>

          {/* Toggle modo */}
          <div className="tab-bar mb-5" style={{ width: '100%' }}>
            <button type="button" onClick={() => setModoAcesso('militar')} className={`tab-item ${modoAcesso === 'militar' ? 'active' : ''}`} style={{ flex: 1 }}>
              <User size={14} />
              <span>Militar</span>
            </button>
            <button type="button" onClick={() => setModoAcesso('admin')} className={`tab-item ${modoAcesso === 'admin' ? 'active' : ''}`} style={{ flex: 1 }}>
              <ShieldCheckered size={14} />
              <span>Administração</span>
            </button>
          </div>

          {/* Feedback */}
          <AnimatePresence>
            {feedback && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-4">
                <div className={`feedback-banner ${feedback.type === 'error' ? 'feedback-error' : feedback.type === 'warning' ? 'feedback-warning' : 'feedback-success'}`}>
                  {feedback.type === 'success' ? <CheckCircle size={16} style={{ flexShrink: 0 }} /> : <WarningCircle size={16} style={{ flexShrink: 0 }} />}
                  <span className="t-caption">{feedback.message}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* CPF */}
            <div className="field-group">
              <label className="field-label">CPF do Militar</label>
              <input type="text" placeholder="000.000.000-00" value={cpf} onChange={handleCPFChange} maxLength={14} className="field-input" required />
            </div>

            {/* Senha */}
            <div className="field-group">
              <label className="field-label">Senha</label>
              <div style={{ position: 'relative' }}>
                <input type={showSenha ? 'text' : 'password'} placeholder="Digite sua senha" value={senha}
                  onChange={(e) => setSenha(e.target.value)} className="field-input" style={{ paddingRight: 44 }} required />
                <button type="button" onClick={() => setShowSenha(!showSenha)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#8a9475', padding: 4 }}>
                  {showSenha ? <EyeSlash size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Manter conectado */}
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input type="checkbox" checked={manterConectado} onChange={e => setManterConectado(e.target.checked)}
                style={{ width: 16, height: 16, borderRadius: 4, accentColor: '#434e2a', cursor: 'pointer' }} />
              <span className="t-caption" style={{ color: '#5a6642' }}>Manter-se conectado por 90 dias</span>
            </label>

            <button type="submit" disabled={loading} className="btn btn-primary btn-lg w-full">
              {loading ? <><SpinnerGap size={18} className="animate-spin" /><span>Autenticando...</span></> : 'Entrar no Sistema'}
            </button>

            <p className="text-center t-caption" style={{ color: '#8a9475' }}>
              Ainda não tem acesso?{' '}
              <button type="button" onClick={() => onNavigate('/auth/cadastro')}
                style={{ color: '#434e2a', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline', fontSize: 'inherit' }}>
                Solicitar Acesso
              </button>
            </p>
          </form>
        </motion.div>
      </main>

      <footer className="relative z-10 py-4 text-center">
        <span style={{ fontSize: 12, color: 'rgba(244,246,238,0.40)' }}>SisCMat © 2026 — Autenticação Segura JWT (90 dias)</span>
      </footer>
    </div>
  );
}
