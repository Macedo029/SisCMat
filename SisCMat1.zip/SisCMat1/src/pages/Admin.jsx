import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Users, UploadSimple, MagnifyingGlass, Check, X, Buildings, SpinnerGap, UserPlus, WarningCircle } from '@phosphor-icons/react';
import { Header } from '../components/Header.jsx';
import { supabase } from '../lib/supabaseClient.js';

export function Admin({ userPerfil, onLogout }) {
  const [searchMilitar, setSearchMilitar] = useState('');
  const [solicitacoes, setSolicitacoes] = useState([]);
  const [importPreview, setImportPreview] = useState(null);
  const [feedback, setFeedback] = useState(null);

  const [equipe, setEquipe] = useState([
    { id:'1', nome:'Ten. Camila Rocha',       funcao:'Chefe de seção',           iniciais:'CR', isAdm:true,  isChefe:true  },
    { id:'2', nome:'3º Sgt. Marcos Ribeiro',  funcao:'Encarregado de patrimônio', iniciais:'MR', isAdm:false, isChefe:true  },
    { id:'3', nome:'Cb. André Nunes',         funcao:'Auxiliar de estoque',       iniciais:'AN', isAdm:false, isChefe:false },
  ]);

  const [secoesOM] = useState([
    { id:'s1', nome:'Reserva de Armas — 1ª Cia', sigla:'ARMAS-1CIA', chefe:'Ten. Camila Rocha'      },
    { id:'s2', nome:'Almoxarifado Geral',          sigla:'ALMOX',     chefe:'3º Sgt. Marcos Ribeiro' },
    { id:'s3', nome:'Pelotão de Comunicações',     sigla:'PEL-COM',   chefe:'Cap. Fonseca'           },
  ]);

  useEffect(() => {
    supabase.from('perfis').select('*, secao:secoes(nome, sigla)').eq('status_aprovacao','Pending')
      .then(({ data }) => { if (data) setSolicitacoes(data); }).catch(() => {});
  }, []);

  const handleAprovar = async (s) => {
    try {
      await supabase.from('perfis').update({ status_aprovacao:'Approved', aprovado_por: userPerfil?.id, data_aprovacao: new Date().toISOString() }).eq('id', s.id);
      setSolicitacoes(prev => prev.filter(x => x.id !== s.id));
      setFeedback({ type:'success', message:`Acesso de ${s.nome_guerra || s.nome_completo} aprovado!` });
    } catch { setFeedback({ type:'error', message:'Erro ao aprovar solicitação.' }); }
  };

  const togglePerm = (id, field) => setEquipe(prev => prev.map(m => m.id === id ? { ...m, [field]: !m[field] } : m));

  const equipeFiltrada = equipe.filter(m => m.nome.toLowerCase().includes(searchMilitar.toLowerCase()));

  const btnToggle = (active, label, onClick) => (
    <button onClick={onClick} className="btn btn-sm"
      style={{ background: active ? '#434e2a' : '#f4f6ee', color: active ? '#f4f6ee' : '#8a9475', border: `1px solid ${active ? '#434e2a' : 'rgba(180,190,160,0.65)'}` }}>
      {label}
    </button>
  );

  return (
    <div className="page-wrapper space-y-6">
      <Header userPerfil={userPerfil} onLogout={onLogout} />

      {/* Título */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="t-title-page" style={{ color:'#2d371b' }}>Administração da seção</h2>
          <p className="t-caption" style={{ color:'#8a9475', marginTop:4 }}>Equipe, permissões, aprovações e importação de materiais.</p>
        </div>
        <span className="badge badge-green">
          <ShieldCheck size={13} weight="fill" />
          Perfil Administrador
        </span>
      </div>

      {/* Feedback */}
      <AnimatePresence>
        {feedback && (
          <motion.div initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }}>
            <div className={`feedback-banner ${feedback.type === 'error' ? 'feedback-error' : 'feedback-success'}`}>
              {feedback.type === 'error' ? <WarningCircle size={16} style={{ flexShrink:0 }} /> : <Check size={16} style={{ flexShrink:0 }} />}
              <span className="t-caption">{feedback.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Solicitações pendentes */}
      {solicitacoes.length > 0 && (
        <section className="card space-y-3">
          <div className="flex items-center gap-2 pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
            <UserPlus size={16} color="#92600a" weight="duotone" />
            <p className="t-body-strong" style={{ color:'#2d371b' }}>Solicitações de acesso pendentes</p>
            <span className="badge badge-amber" style={{ marginLeft:'auto' }}>{solicitacoes.length}</span>
          </div>
          {solicitacoes.map(s => (
            <div key={s.id} className="card-row">
              <div className="icon-box icon-box-md" style={{ background:'#fef9ec', flexShrink:0 }}>
                <UserPlus size={17} color="#92600a" />
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <p className="t-caption" style={{ fontWeight:600, color:'#2d371b', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{s.nome_completo}</p>
                <p className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0, fontWeight:500 }}>{s.posto_graduacao} · {s.secao_solicitada}</p>
              </div>
              <div className="flex gap-2" style={{ flexShrink:0 }}>
                <button onClick={() => handleAprovar(s)} className="btn btn-sm" style={{ background:'#f0fdf4', color:'#3a6642', border:'1px solid rgba(58,102,66,0.25)' }}>
                  <Check size={13} /><span>Aprovar</span>
                </button>
                <button onClick={() => setSolicitacoes(prev => prev.filter(x => x.id !== s.id))} className="btn btn-sm" style={{ background:'#fef2f2', color:'#9b1c1c', border:'1px solid rgba(155,28,28,0.2)' }}>
                  <X size={13} />
                </button>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Grid principal */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">

        {/* Gestão de pessoas */}
        <section className="lg:col-span-7 card space-y-4">
          <div className="pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
            <p className="t-subtitle" style={{ color:'#2d371b' }}>Gestão de pessoas</p>
            <p className="t-caption" style={{ color:'#8a9475', marginTop:3 }}>28 militares vinculados à seção</p>
          </div>

          <div style={{ position:'relative' }}>
            <MagnifyingGlass size={15} color="#8a9475" style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', pointerEvents:'none' }} />
            <input type="text" placeholder="Buscar militar" value={searchMilitar} onChange={e => setSearchMilitar(e.target.value)}
              className="field-input" style={{ paddingLeft:40 }} />
          </div>

          <div className="flex items-center justify-between px-2">
            <span className="section-label">Militar</span>
            <span className="section-label">Permissões</span>
          </div>

          <div className="space-y-2">
            {equipeFiltrada.map(m => (
              <div key={m.id} className="card-row">
                <div className="icon-box icon-box-md flex-shrink-0"
                  style={{ background:'#434e2a', color:'#f4f6ee', fontSize:12, fontWeight:800 }}>
                  {m.iniciais}
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <p className="t-caption" style={{ fontWeight:600, color:'#2d371b', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{m.nome}</p>
                  <p className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0, fontWeight:500 }}>{m.funcao}</p>
                </div>
                <div className="flex items-center gap-1.5" style={{ flexShrink:0 }}>
                  {btnToggle(m.isAdm, 'ADM', () => togglePerm(m.id, 'isAdm'))}
                  {btnToggle(m.isChefe, 'CHEFE', () => togglePerm(m.id, 'isChefe'))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Importação em lote */}
        <section className="lg:col-span-5 card space-y-4 flex flex-col">
          <div className="pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
            <p className="t-subtitle" style={{ color:'#2d371b' }}>Importação em lote</p>
            <p className="t-caption" style={{ color:'#8a9475', marginTop:3 }}>Adicione ou atualize materiais por planilha.</p>
          </div>

          <label style={{ cursor:'pointer', display:'block' }}>
            <div style={{ padding:32, borderRadius:20, background:'#ffffff', border:'2px dashed rgba(180,190,160,0.7)', textAlign:'center', display:'flex', flexDirection:'column', alignItems:'center', gap:12, transition:'border-color 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#434e2a'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(180,190,160,0.7)'}>
              <div className="icon-box icon-box-lg" style={{ background:'#f4f6ee', margin:'0 auto' }}>
                <UploadSimple size={24} color="#8a9475" />
              </div>
              <div>
                <p className="t-body-strong" style={{ color:'#2d371b' }}>Arraste sua planilha até aqui</p>
                <p className="t-caption" style={{ color:'#8a9475' }}>CSV ou XLSX</p>
              </div>
              <button type="button" className="btn btn-primary btn-sm">Selecionar arquivo</button>
            </div>
            <input type="file" accept=".csv,.xlsx" className="hidden"
              onChange={e => { if (e.target.files[0]) setImportPreview([{ nome:'Fuzil IA2 5.56mm', cat:'Armamento' },{ nome:'Colete Balístico', cat:'Proteção' },{ nome:'Rádio Harris', cat:'Comunicação' }]); }} />
          </label>

          {importPreview && (
            <div className="card-row" style={{ background:'#f0fdf4', border:'1px solid rgba(58,102,66,0.25)' }}>
              <Check size={15} color="#3a6642" weight="bold" style={{ flexShrink:0 }} />
              <div>
                <p className="t-caption" style={{ fontWeight:600, color:'#3a6642' }}>{importPreview.length} itens detectados</p>
                <p className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0 }}>Validação concluída sem erros.</p>
              </div>
            </div>
          )}

          <div className="card-row" style={{ marginTop:'auto' }}>
            <ShieldCheck size={15} color="#3a6642" style={{ flexShrink:0 }} />
            <p className="t-caption" style={{ color:'#8a9475' }}>Dados gravados apenas após integração com servidor.</p>
          </div>
        </section>
      </div>

      {/* Seções da OM */}
      <section className="card space-y-4">
        <div className="flex items-center gap-2 pb-3" style={{ borderBottom:'1px solid rgba(180,190,160,0.55)' }}>
          <Buildings size={16} color="#5a6642" weight="duotone" />
          <p className="t-body-strong" style={{ color:'#2d371b' }}>Seções da OM</p>
          <span className="badge badge-neutral" style={{ marginLeft:'auto' }}>{secoesOM.length} seções</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {secoesOM.map(s => (
            <div key={s.id} style={{ padding:16, borderRadius:18, background:'#ffffff', border:'1px solid rgba(180,190,160,0.55)', display:'flex', flexDirection:'column', gap:6 }}>
              <span className="badge badge-neutral" style={{ width:'fit-content' }}>{s.sigla}</span>
              <p className="t-caption" style={{ fontWeight:600, color:'#2d371b' }}>{s.nome}</p>
              <p className="t-label" style={{ color:'#8a9475', textTransform:'none', letterSpacing:0 }}>{s.chefe}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="pt-2 text-center">
        <span className="t-caption" style={{ color:'#8a9475' }}>SisCMat © 2026 — Created by Ackley Labs</span>
      </footer>
    </div>
  );
}
