import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ClipboardText, WarningCircle, Users, Package, ArrowRight, Clock, CheckCircle } from '@phosphor-icons/react';
import { Header } from '../components/Header.jsx';
import { verificarExpedienteSecao } from '../lib/supabaseClient.js';

const METRICS = [
  { key:'cautelas',  label:'Cautelas Ativas',       value:'06', sub:'Materiais sob responsabilidade', icon: ClipboardText, iconBg:'#f4f6ee',     iconColor:'#5a6642', path:'/app/cautelas', alert: false },
  { key:'pendentes', label:'Devoluções Pendentes',   value:'02', sub:'Uma cautela vence hoje',          icon: WarningCircle, iconBg:'#fef9ec',     iconColor:'#92600a', path:'/app/cautelas', alert: true  },
  { key:'efetivo',   label:'Efetivo da Seção',       value:'28', sub:'Militares cadastrados',           icon: Users,         iconBg:'#f4f6ee',     iconColor:'#5a6642', path:'/app/admin',   alert: false },
  { key:'estoque',   label:'Itens em Estoque',        value:'145',sub:'12 categorias cadastradas',      icon: Package,       iconBg:'#f4f6ee',     iconColor:'#5a6642', path:'/app/materiais',alert:false },
];

const RECENT = [
  { id:1, icon: Package,     iconBg:'#fef9ec', iconColor:'#92600a', title:'Rádio portátil Motorola', sub:'Cautela aberta · Sd. Alves · 09:42' },
  { id:2, icon: CheckCircle, iconBg:'#f0fdf4', iconColor:'#3a6642', title:'Lanterna tática',          sub:'Devolvida · Cb. Nunes · 08:15'     },
  { id:3, icon: Clock,       iconBg:'#f4f6ee', iconColor:'#8a9475', title:'Kit de ferramentas',       sub:'Movimentação registrada · Sgt. Lima · Ontem' },
];

export function Dashboard({ userPerfil, onNavigate, onLogout }) {
  const [expedienteStatus, setExpedienteStatus] = useState(null);
  const ease = { duration: 0.25, ease: [0.4, 0, 0.2, 1] };

  useEffect(() => {
    if (userPerfil?.secao_id) {
      verificarExpedienteSecao(userPerfil.secao_id).then(setExpedienteStatus).catch(() => {});
    }
  }, [userPerfil]);

  return (
    <div className="page-wrapper space-y-6">
      <Header userPerfil={userPerfil} onLogout={onLogout} />

      {/* Alerta expediente */}
      {expedienteStatus && !expedienteStatus.aberto && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="feedback-banner feedback-warning">
          <Clock size={18} style={{ flexShrink: 0, marginTop: 2 }} weight="duotone" />
          <div>
            <span className="t-label" style={{ display: 'block', marginBottom: 3 }}>Expediente Encerrado</span>
            <span className="t-caption">{expedienteStatus.mensagem}</span>
          </div>
        </motion.div>
      )}

      {/* Métricas */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="section-label">Métricas da Seção</p>
          <span className="badge badge-neutral">Sex · 02 Out</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {METRICS.map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.button
                key={card.key}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...ease, delay: i * 0.06 }}
                onClick={() => onNavigate(card.path)}
                className="card card-interactive text-left w-full space-y-3"
                style={{ display: 'block' }}
              >
                <div className="icon-box icon-box-md" style={{ background: card.iconBg }}>
                  <Icon size={21} weight="duotone" color={card.iconColor} />
                </div>
                <div className="space-y-1">
                  <p className="section-label">{card.label}</p>
                  <p className="t-title-card" style={{ color: '#2d371b' }}>{card.value}</p>
                  <p className="t-caption" style={{ color: card.alert ? '#92600a' : '#8a9475', fontWeight: card.alert ? 600 : 500 }}>
                    {card.sub}
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Atividade recente */}
      <motion.section
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ ...ease, delay: 0.22 }}
        className="card space-y-4"
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="t-subtitle" style={{ color: '#2d371b' }}>Atividade recente</h3>
            <p className="t-caption" style={{ color: '#8a9475' }}>Últimas movimentações da seção</p>
          </div>
          <button onClick={() => onNavigate('/app/cautelas')} className="btn btn-secondary btn-sm">
            <span>Ver cautelas</span>
            <ArrowRight size={13} weight="bold" />
          </button>
        </div>

        <div className="space-y-2">
          {RECENT.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.id} className="card-row">
                <div className="icon-box icon-box-md flex-shrink-0" style={{ background: item.iconBg }}>
                  <Icon size={18} weight={item.id === 2 ? 'fill' : 'duotone'} color={item.iconColor} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="t-caption" style={{ fontWeight: 600, color: '#2d371b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.title}</p>
                  <p className="t-label" style={{ color: '#8a9475', textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>{item.sub}</p>
                </div>
              </div>
            );
          })}
        </div>
      </motion.section>
    </div>
  );
}
