import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, ArrowLeft, Scroll, LockKey, CheckCircle } from '@phosphor-icons/react';

export function Termos({ onNavigate }) {
  return (
    <div className="relative min-h-screen w-full bg-[#0d121c] text-white flex flex-col justify-between overflow-hidden font-sans">
      
      {/* Background Militar do Exército Brasileiro */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center filter brightness-[0.35] contrast-[1.1] scale-105"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=2000&q=80')`
        }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-t from-[#0d121c] via-black/50 to-black/80" />

      {/* Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-6 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('/')}>
          <div className="w-10 h-10 rounded-2xl bg-[#434e2a] border border-white/20 flex items-center justify-center text-emerald-400 shadow-xl">
            <ShieldCheck size={26} weight="duotone" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight leading-none text-white font-['Outfit']">SisCMat</h1>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400">Exército Brasileiro</span>
          </div>
        </div>

        <button
          onClick={() => onNavigate('/')}
          className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-xs font-bold text-slate-200 backdrop-blur-md border border-white/10 transition-all cursor-pointer"
        >
          <ArrowLeft size={16} />
          <span>Voltar ao Início</span>
        </button>
      </header>

      {/* Conteúdo Principal dos Termos */}
      <main className="relative z-10 max-w-4xl w-full mx-auto px-6 py-10 flex-1">
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-[#f4f6ee] text-[#2d371b] rounded-3xl p-8 md:p-12 shadow-2xl border border-white/80 space-y-6"
        >
          <div className="flex items-center gap-3 pb-4 border-b border-slate-300">
            <div className="w-12 h-12 rounded-2xl bg-[#434e2a] text-white flex items-center justify-center shrink-0">
              <Scroll size={28} weight="duotone" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-black text-[#2d371b] tracking-tight font-['Outfit']">
                Termos de Uso & Consentimento de Dados
              </h2>
              <p className="text-xs text-slate-600">Regulamentação e Auditoria Digital — Exército Brasileiro (EB)</p>
            </div>
          </div>

          <div className="space-y-6 text-xs md:text-sm text-slate-700 leading-relaxed">
            
            <section className="space-y-2">
              <h3 className="text-sm font-bold text-[#2d371b] uppercase tracking-wider">1. FINALIDADE DO SISTEMA E ESCOPO MILITAR</h3>
              <p>
                O SisCMat (Sistema de Controle de Materiais e Cautela Militar) é uma plataforma de uso restrito e interno do Exército Brasileiro, desenvolvida para substituir o livro impresso e digitalizar com blindagem a cadeia de custódia de suprimentos, materiais e armamentos. Todos os dados inseridos (CPF, Nome de Guerra, Posto/Graduação, Registros de Lacres e Mídias) destinam-se exclusivamente ao controle patrimonial da Organização Militar.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="text-sm font-bold text-[#2d371b] uppercase tracking-wider">2. LEI GERAL DE PROTEÇÃO DE DADOS (LGPD MILITAR)</h3>
              <p>
                Em conformidade com a Lei nº 13.709/2018 (LGPD), as informações cadastrais dos militares são armazenadas com segurança via Supabase PostgreSQL criptografado e retenção de token JWT local por 90 dias. Os dados não serão comercializados nem disponibilizados fora do âmbito administrativo e operacional do Exército Brasileiro.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="text-sm font-bold text-[#2d371b] uppercase tracking-wider">3. RASTREABILIDADE IMUTÁVEL E CÓDIGO PENAL MILITAR</h3>
              <p>
                Todas as cautelas abertas, devoluções efetuadas com lacres físicos, cadastros de materiais e aprovações de acesso são gravadas de forma permanente e imutável no log de auditoria. Fica vedada qualquer tentativa de adulteração de lacre ou prestação de informação falsa, estando o militar sujeito às sanções do Código Penal Militar (Decreto-Lei nº 1.001/1969) e do Regulamento Disciplinar do Exército (RDE - Decreto nº 4.346/2002).
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="text-sm font-bold text-[#2d371b] uppercase tracking-wider">4. FINGERPRINT DE SEGURANÇA E DISPOSITIVOS</h3>
              <p>
                Para assegurar que o sistema não seja acessado por terceiros não autorizados, cada login registra o endereço IP, tipo de dispositivo (Desktop ou Celular), Sistema Operacional e Navegador. O militar poderá verificar suas sessões ativas e deslogar remotamente qualquer dispositivo suspeito através do painel de controle.
              </p>
            </section>

          </div>

          <div className="pt-4 border-t border-slate-300 flex items-center justify-between text-xs text-slate-500">
            <span>Última atualização: Outubro de 2026</span>
            <span className="font-bold text-[#2d371b]">Ackley Labs</span>
          </div>

        </motion.div>

      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 text-center text-xs text-slate-400 border-t border-white/10">
        SisCMat &copy; 2026 — Created by Ackley Labs • Todos os direitos reservados
      </footer>

    </div>
  );
}
