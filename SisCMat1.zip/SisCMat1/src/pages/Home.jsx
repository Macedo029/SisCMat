import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, ArrowRight, ClipboardText, WarningCircle, Package, Seal, Camera, CheckCircle, Sparkle } from '@phosphor-icons/react';

const BG_URL = 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=2000&q=80';

const FEATURED_CARDS = [
  {
    id: 'visao', title: 'Visão da Seção', badge: 'Métricas em Tempo Real', icon: ClipboardText,
    content: (
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div style={{ background: '#fff', border: '1px solid rgba(180,190,160,0.55)', borderRadius: 18, padding: 16 }}>
            <ClipboardText size={20} color="#434e2a" weight="duotone" />
            <p className="t-label" style={{ color: '#8a9475', marginTop: 8 }}>Cautelas Ativas</p>
            <p className="t-title-card" style={{ color: '#2d371b' }}>06</p>
          </div>
          <div style={{ background: '#fff', border: '1px solid rgba(180,190,160,0.55)', borderRadius: 18, padding: 16 }}>
            <WarningCircle size={20} color="#92600a" weight="duotone" />
            <p className="t-label" style={{ color: '#8a9475', marginTop: 8 }}>Pendências</p>
            <p className="t-title-card" style={{ color: '#2d371b' }}>02</p>
          </div>
        </div>
        <div className="card-row" style={{ background: '#fff' }}>
          <Package size={17} color="#8a9475" style={{ flexShrink: 0 }} />
          <div className="min-w-0">
            <p className="t-caption" style={{ color: '#2d371b', fontWeight: 600 }}>Rádio portátil TPH900</p>
            <p className="t-label" style={{ color: '#8a9475', textTransform: 'none', letterSpacing: 0 }}>Cautela aberta · 09:42</p>
          </div>
        </div>
      </div>
    )
  },
  {
    id: 'catalogo', title: 'Catálogo de Armamento e Carga', badge: 'Controle de Patrimônio', icon: Package,
    content: (
      <div className="space-y-2">
        {[
          { img: 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=200&q=80', nome: 'Rádio TPH900', pat: '084317', lacre: '19A-004', disp: '14/18' },
          { img: 'https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?auto=format&fit=crop&w=200&q=80', nome: 'Lanterna Tática Pro', pat: '072640', lacre: '21B-012', disp: '18/24' },
        ].map((item, i) => (
          <div key={i} className="card-row" style={{ background: '#fff' }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, overflow: 'hidden', flexShrink: 0, background: '#e5e7eb' }}>
              <img src={item.img} alt={item.nome} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p className="t-caption" style={{ color: '#2d371b', fontWeight: 600 }}>{item.nome}</p>
              <p className="t-label" style={{ color: '#8a9475', textTransform: 'none', letterSpacing: 0 }}>Pat. {item.pat} · {item.lacre}</p>
            </div>
            <span className="badge badge-green" style={{ flexShrink: 0 }}>{item.disp}</span>
          </div>
        ))}
      </div>
    )
  },
  {
    id: 'lacres', title: 'Inspeção de Lacres em Lote', badge: 'Foto-Registro na Entrega', icon: Camera,
    content: (
      <div>
        <div style={{ background: '#fff', border: '1px solid rgba(180,190,160,0.55)', borderRadius: 18, padding: 14 }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Seal size={15} color="#434e2a" />
              <span className="t-caption" style={{ color: '#2d371b', fontWeight: 600 }}>Lacre LAC-2026-8849</span>
            </div>
            <span className="badge badge-green">Verificado</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {['https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=200&q=80','https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?auto=format&fit=crop&w=200&q=80','https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=200&q=80'].map((src, i) => (
              <div key={i} style={{ height: 56, borderRadius: 12, overflow: 'hidden', background: '#e5e7eb' }}>
                <img src={src} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="" />
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  },
  {
    id: 'auditoria', title: 'Cadeia de Custódia Imutável', badge: 'Auditoria & RLS Supabase', icon: ShieldCheck,
    content: (
      <div className="space-y-2">
        {[
          { text: 'Passagem de Comando Auditável', meta: 'LOG-883' },
          { text: 'Retenção de Sessão por 90 Dias',  meta: 'JWT' },
          { text: 'Hard Delete proibido em cautelas', meta: 'RLS' },
        ].map((item, i) => (
          <div key={i} className="card-row" style={{ background: '#fff' }}>
            <div className="icon-box icon-box-sm" style={{ background: '#dcfce7', flexShrink: 0 }}>
              <CheckCircle size={14} color="#3a6642" weight="fill" />
            </div>
            <span className="t-caption" style={{ color: '#2d371b', flex: 1 }}>{item.text}</span>
            <span className="t-label" style={{ color: '#8a9475', fontFamily: 'monospace', textTransform: 'none', letterSpacing: 0 }}>{item.meta}</span>
          </div>
        ))}
      </div>
    )
  }
];

export function Home({ onNavigate }) {
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActiveIdx(prev => (prev + 1) % FEATURED_CARDS.length), 4500);
    return () => clearInterval(t);
  }, []);

  const card = FEATURED_CARDS[activeIdx];
  const CardIcon = card.icon;

  return (
    <div className="relative min-h-screen w-full overflow-hidden flex flex-col justify-between" style={{ background: '#0d121c' }}>
      {/* Background */}
      <div className="absolute inset-0 z-0 bg-cover bg-center scale-105" style={{ backgroundImage: `url('${BG_URL}')`, filter: 'brightness(0.36) contrast(1.1)' }} />
      <div className="absolute inset-0 z-0" style={{ background: 'linear-gradient(to top, #0d121c 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.6) 100%)' }} />

      {/* Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-6 flex items-center gap-3">
        <div className="icon-box icon-box-md" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#86efac' }}>
          <ShieldCheck size={24} weight="duotone" />
        </div>
        <div>
          <h1 className="t-title-card" style={{ color: '#ffffff', marginBottom: 0, fontFamily: 'Outfit, system-ui, sans-serif', fontSize: 20, fontWeight: 800 }}>SisCMat</h1>
          <span style={{ fontSize: 10, color: '#86efac', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase' }}>Exército Brasileiro</span>
        </div>
      </header>

      {/* Main */}
      <main className="relative z-10 max-w-7xl w-full mx-auto px-6 flex-1 flex flex-col justify-center py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">

          {/* Hero texto */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full" style={{ background: 'rgba(134,239,172,0.10)', border: '1px solid rgba(134,239,172,0.2)' }}>
              <Sparkle size={13} color="#86efac" />
              <span style={{ fontSize: 12, color: '#86efac', fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Gestão Logística & Cautela Militar</span>
            </div>

            <h2 className="t-hero" style={{ color: '#ffffff', lineHeight: 1.1 }}>
              Controle claro.<br />
              <span style={{ color: '#86efac' }}>Prontidão constante.</span>
            </h2>

            <p className="t-body" style={{ color: 'rgba(244,246,238,0.72)', maxWidth: 480, lineHeight: 1.7 }}>
              Acompanhe materiais, cautelas com registro em lote de lacres físicos e a rotina da sua seção em um único sistema blindado.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <button onClick={() => onNavigate('/auth/login')}
                className="btn btn-lg group"
                style={{ background: '#434e2a', color: '#f4f6ee', boxShadow: '0 4px 20px rgba(67,78,42,0.4)' }}>
                <span>Acessar plataforma</span>
                <ArrowRight size={18} weight="bold" />
              </button>
              <button onClick={() => onNavigate('/auth/cadastro')}
                className="btn btn-lg"
                style={{ background: 'rgba(244,246,238,0.95)', color: '#2d371b', boxShadow: '0 4px 16px rgba(0,0,0,0.15)' }}>
                Solicitar acesso
              </button>
            </div>
          </motion.div>

          {/* Card flutuante */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="lg:col-span-5">
            <div className="animate-float" style={{
              background: 'rgba(244,246,238,0.97)',
              border: '1px solid rgba(255,255,255,0.85)',
              borderRadius: 24,
              boxShadow: '0 20px 60px rgba(0,0,0,0.20)',
              padding: 24,
            }}>
              {/* Card header */}
              <div className="flex items-center justify-between pb-4 mb-4" style={{ borderBottom: '1px solid rgba(180,190,160,0.5)' }}>
                <div className="flex items-center gap-2">
                  <span className="dot-live" />
                  <span className="t-label" style={{ color: '#8a9475' }}>{card.badge}</span>
                </div>
                <span className="t-label" style={{ color: '#8a9475', textTransform: 'none', letterSpacing: 0, fontWeight: 500 }}>02 OUT 2026</span>
              </div>

              {/* Título do card */}
              <div className="flex items-center gap-2 mb-4">
                <CardIcon size={19} weight="duotone" color="#434e2a" style={{ flexShrink: 0 }} />
                <span className="t-body-strong" style={{ color: '#2d371b' }}>{card.title}</span>
              </div>

              {/* Conteúdo animado */}
              <div style={{ minHeight: 160 }}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={card.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ duration: 0.25 }}
                  >
                    {card.content}
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Indicadores */}
              <div className="flex items-center justify-between pt-4 mt-2" style={{ borderTop: '1px solid rgba(180,190,160,0.45)' }}>
                <div className="flex items-center gap-1.5">
                  {FEATURED_CARDS.map((_, idx) => (
                    <button key={idx} onClick={() => setActiveIdx(idx)} style={{
                      height: 6,
                      width: idx === activeIdx ? 20 : 6,
                      borderRadius: 999,
                      background: idx === activeIdx ? '#434e2a' : 'rgba(180,190,160,0.7)',
                      border: 'none',
                      cursor: 'pointer',
                      transition: 'all 0.3s',
                    }} />
                  ))}
                </div>
                <button onClick={() => onNavigate('/auth/login')} className="btn btn-sm"
                  style={{ background: 'rgba(67,78,42,0.10)', color: '#2d371b', border: 'none' }}>
                  <span>Explorar painel</span>
                  <ArrowRight size={13} weight="bold" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 flex flex-wrap items-center justify-center gap-4 px-6" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <span style={{ fontSize: 12, color: 'rgba(244,246,238,0.45)' }}>SisCMat © 2026 — Exército Brasileiro · Uso Restrito e Interno</span>
        <span style={{ color: 'rgba(255,255,255,0.2)' }}>•</span>
        <span style={{ fontSize: 12, fontWeight: 600, color: 'rgba(244,246,238,0.6)' }}>Created by Ackley Labs</span>
      </footer>
    </div>
  );
}
