import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Eye, EyeSlash, CheckCircle, WarningCircle, SpinnerGap, ArrowLeft, LockKey, Envelope } from '@phosphor-icons/react';
import { cadastrarMilitar, listarSecoes, formatCPF, cleanCPF, validarEmailProvedor } from '../lib/supabaseClient.js';
import { CustomSelect } from '../components/CustomSelect.jsx';
import { ModalTermos } from '../components/ModalTermos.jsx';

const BG_URL = 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=2000&q=80';
const POSTOS = ['Recruta','Soldado','Cabo','3º Sgt','2º Sgt','1º Sgt','Subtenente','2º Ten','1º Ten','Capitão','Major','Tenente-Coronel','Coronel'];

// Provedores aceitos (UI hint)
const PROVEDORES_HINT = 'Gmail, Outlook, Hotmail, Yahoo, iCloud…';

export function Cadastro({ onNavigate }) {
  const [form, setForm] = useState({
    nome: '', sobrenome: '', nomeGuerra: '', postoGraduacao: 'Soldado',
    secaoSolicitada: '', cpf: '', email: '', senha: '', confirmarSenha: ''
  });
  const [secoes, setSecoes] = useState([]);
  const [termosAceito, setTermosAceito] = useState(false);
  const [showModalTermos, setShowModalTermos] = useState(false);
  const [showSenha, setShowSenha] = useState(false);
  const [showConfirmar, setShowConfirmar] = useState(false);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [emailFeedback, setEmailFeedback] = useState(null);
  const [sucesso, setSucesso] = useState(false);

  useEffect(() => {
    listarSecoes(true).then((data) => {
      const nomes = data.map(s => ({ value: s.id, label: s.nome }));
      setSecoes(nomes);
      if (nomes.length > 0) setForm(p => ({ ...p, secaoSolicitada: nomes[0].value }));
    }).catch(() => {
      // Fallback de demonstração
      const demo = [
        { value: 's1', label: 'Almoxarifado Geral' },
        { value: 's2', label: 'Reserva de Armas — 1ª Cia' },
        { value: 's3', label: 'Pelotão de Comunicações' },
      ];
      setSecoes(demo);
      setForm(p => ({ ...p, secaoSolicitada: demo[0].value }));
    });
  }, []);

  const set = (field) => (val) => setForm(p => ({ ...p, [field]: val }));
  const setE = (field) => (e) => setForm(p => ({ ...p, [field]: e.target.value }));

  const handleCPFChange = (e) => {
    setForm(p => ({ ...p, cpf: formatCPF(e.target.value) }));
  };

  const handleEmailBlur = () => {
    if (!form.email) { setEmailFeedback(null); return; }
    const { valido, mensagem } = validarEmailProvedor(form.email);
    setEmailFeedback(valido ? null : { type: 'error', message: mensagem });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFeedback(null);

    if (!termosAceito) {
      setFeedback({ type: 'error', message: 'Aceite os Termos de Consentimento antes de prosseguir.' });
      setShowModalTermos(true);
      return;
    }

    const cpfLimpo = cleanCPF(form.cpf);
    if (cpfLimpo.length !== 11) {
      setFeedback({ type: 'error', message: 'CPF inválido — informe os 11 dígitos.' });
      return;
    }

    const emailVal = validarEmailProvedor(form.email);
    if (!emailVal.valido) {
      setFeedback({ type: 'error', message: emailVal.mensagem });
      return;
    }

    if (form.senha !== form.confirmarSenha) {
      setFeedback({ type: 'error', message: 'As senhas não coincidem.' });
      return;
    }

    if (form.senha.length < 6) {
      setFeedback({ type: 'error', message: 'A senha deve ter pelo menos 6 caracteres.' });
      return;
    }

    const secaoLabel = secoes.find(s => s.value === form.secaoSolicitada)?.label || form.secaoSolicitada;

    setLoading(true);
    try {
      await cadastrarMilitar({
        nome: form.nome,
        sobrenome: form.sobrenome,
        nomeGuerra: form.nomeGuerra,
        postoGraduacao: form.postoGraduacao,
        secaoSolicitada: secaoLabel,
        cpf: form.cpf,
        email: form.email,
        senha: form.senha,
      });

      setSucesso(true);
      setForm({ nome:'', sobrenome:'', nomeGuerra:'', postoGraduacao:'Soldado', secaoSolicitada: secoes[0]?.value || '', cpf:'', email:'', senha:'', confirmarSenha:'' });
      setTermosAceito(false);
    } catch (err) {
      let msg = err.message || 'Falha ao enviar solicitação. Tente novamente.';
      if (msg.includes('already registered') || msg.includes('already exists')) {
        msg = 'Este e-mail já está cadastrado. Caso tenha esquecido a senha, entre em contato com a administração.';
      }
      setFeedback({ type: 'error', message: msg });
    } finally {
      setLoading(false);
    }
  };

  if (sucesso) {
    return (
      <div className="relative min-h-screen w-full flex items-center justify-center" style={{ background: '#0d121c' }}>
        <div className="absolute inset-0 z-0 bg-cover bg-center" style={{ backgroundImage: `url('${BG_URL}')`, filter: 'brightness(0.36)' }} />
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          style={{ position: 'relative', zIndex: 10, maxWidth: 420, width: '100%', margin: '0 auto', padding: '0 16px' }}>
          <div style={{ background: 'rgba(244,246,238,0.98)', border: '1px solid rgba(255,255,255,0.85)', borderRadius: 24, boxShadow: '0 20px 60px rgba(0,0,0,0.22)', padding: 40, textAlign: 'center' }}>
            <div className="icon-box icon-box-lg" style={{ background: '#f0fdf4', margin: '0 auto 20px' }}>
              <CheckCircle size={32} color="#3a6642" weight="fill" />
            </div>
            <h2 className="t-title-page" style={{ color: '#2d371b', marginBottom: 12 }}>Solicitação enviada!</h2>
            <p className="t-caption" style={{ color: '#8a9475', lineHeight: 1.65, marginBottom: 24 }}>
              Sua solicitação foi registrada e será analisada pelo Chefe de Seção ou Administrador. Você receberá comunicação quando o acesso for aprovado.
            </p>
            <button onClick={() => onNavigate('/auth/login')} className="btn btn-primary btn-lg w-full">
              Ir para o Login
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  const inp = (props) => <input {...props} className="field-input" />;

  return (
    <div className="relative min-h-screen w-full overflow-hidden flex flex-col" style={{ background: '#0d121c' }}>
      <div className="absolute inset-0 z-0 bg-cover bg-center scale-105" style={{ backgroundImage: `url('${BG_URL}')`, filter: 'brightness(0.36) contrast(1.1)' }} />
      <div className="absolute inset-0 z-0" style={{ background: 'linear-gradient(to top, #0d121c 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.6) 100%)' }} />

      {/* Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-6 py-5 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('/')}>
          <div className="icon-box icon-box-md" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#86efac' }}>
            <ShieldCheck size={22} weight="duotone" />
          </div>
          <div>
            <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: 18, fontWeight: 800, color: '#ffffff', lineHeight: 1, margin: 0 }}>SisCMat</h1>
            <span style={{ fontSize: 10, color: '#86efac', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Exército Brasileiro</span>
          </div>
        </div>
        <button onClick={() => onNavigate('/auth/login')} className="btn btn-sm"
          style={{ background: 'rgba(244,246,238,0.10)', color: 'rgba(244,246,238,0.80)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <ArrowLeft size={14} /><span>Já tenho conta</span>
        </button>
      </header>

      {/* Formulário */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 12 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 0.3 }}
          style={{
            width: '100%', maxWidth: 640,
            background: 'rgba(244,246,238,0.98)', border: '1px solid rgba(255,255,255,0.85)',
            borderRadius: 24, boxShadow: '0 20px 60px rgba(0,0,0,0.22)',
            padding: 'clamp(24px,5vw,36px)',
          }}
        >
          <div className="space-y-1 mb-5">
            <span className="badge badge-neutral">Novo Cadastro Militar</span>
            <h2 className="t-title-page" style={{ color: '#2d371b', marginTop: 8 }}>Solicitar acesso</h2>
            <p className="t-caption" style={{ color: '#8a9475' }}>Preencha seus dados para análise pela chefia da seção.</p>
          </div>

          <AnimatePresence>
            {feedback && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-5">
                <div className={`feedback-banner ${feedback.type === 'error' ? 'feedback-error' : 'feedback-success'}`}>
                  {feedback.type === 'error' ? <WarningCircle size={16} style={{ flexShrink: 0 }} /> : <CheckCircle size={16} style={{ flexShrink: 0 }} />}
                  <span className="t-caption">{feedback.message}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Linha 1: Nome + Sobrenome */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="field-group">
                <label className="field-label">Nome</label>
                {inp({ type:'text', placeholder:'Seu nome', value: form.nome, onChange: setE('nome'), required: true })}
              </div>
              <div className="field-group">
                <label className="field-label">Sobrenome</label>
                {inp({ type:'text', placeholder:'Seu sobrenome', value: form.sobrenome, onChange: setE('sobrenome'), required: true })}
              </div>
            </div>

            {/* Linha 2: Nome de guerra + Posto */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="field-group">
                <label className="field-label">Nome de guerra</label>
                {inp({ type:'text', placeholder:'Como é conhecido', value: form.nomeGuerra, onChange: setE('nomeGuerra'), required: true })}
              </div>
              <div className="field-group">
                <label className="field-label">Posto ou Graduação</label>
                <CustomSelect options={POSTOS} value={form.postoGraduacao} onChange={set('postoGraduacao')} placeholder="Selecione" />
              </div>
            </div>

            {/* Linha 3: CPF + Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="field-group">
                <label className="field-label">CPF</label>
                {inp({ type:'text', placeholder:'000.000.000-00', value: form.cpf, onChange: handleCPFChange, maxLength: 14, required: true })}
              </div>
              <div className="field-group">
                <label className="field-label">E-mail pessoal</label>
                <div style={{ position: 'relative' }}>
                  <Envelope size={15} color="#8a9475" style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', pointerEvents:'none' }} />
                  {inp({
                    type:'email',
                    placeholder:`ex: voce@${PROVEDORES_HINT.split(',')[0].toLowerCase().trim()}.com`,
                    value: form.email,
                    onChange: setE('email'),
                    onBlur: handleEmailBlur,
                    style: { paddingLeft: 40 },
                    required: true
                  })}
                </div>
                {emailFeedback && (
                  <p className="t-label" style={{ color: '#9b1c1c', textTransform: 'none', letterSpacing: 0, marginTop: 4 }}>
                    {emailFeedback.message}
                  </p>
                )}
                <p className="t-label" style={{ color: '#8a9475', textTransform: 'none', letterSpacing: 0, marginTop: 4 }}>
                  Aceito: {PROVEDORES_HINT}
                </p>
              </div>
            </div>

            {/* Linha 4: Senha + Confirmar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="field-group">
                <label className="field-label">Senha</label>
                <div style={{ position: 'relative' }}>
                  {inp({ type: showSenha ? 'text' : 'password', placeholder: 'Mín. 6 caracteres', value: form.senha, onChange: setE('senha'), style: { paddingRight: 44 }, required: true })}
                  <button type="button" onClick={() => setShowSenha(!showSenha)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#8a9475' }}>
                    {showSenha ? <EyeSlash size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>
              <div className="field-group">
                <label className="field-label">Confirmar senha</label>
                <div style={{ position: 'relative' }}>
                  {inp({ type: showConfirmar ? 'text' : 'password', placeholder: 'Repita a senha', value: form.confirmarSenha, onChange: setE('confirmarSenha'), style: { paddingRight: 44 }, required: true })}
                  <button type="button" onClick={() => setShowConfirmar(!showConfirmar)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#8a9475' }}>
                    {showConfirmar ? <EyeSlash size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Seção solicitada (carregada dinamicamente do banco) */}
            <div className="field-group">
              <label className="field-label">Seção solicitada</label>
              {secoes.length === 0
                ? <div className="field-input" style={{ color: '#8a9475', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <SpinnerGap size={14} className="animate-spin" /> Carregando seções…
                  </div>
                : <CustomSelect
                    options={secoes}
                    value={form.secaoSolicitada}
                    onChange={set('secaoSolicitada')}
                    placeholder="Selecione a seção"
                  />
              }
              <p className="t-label" style={{ color: '#8a9475', textTransform:'none', letterSpacing:0, marginTop:4 }}>
                As seções são gerenciadas pelo Administrador da OM.
              </p>
            </div>

            {/* Termos de consentimento */}
            <button
              type="button"
              onClick={() => { if (!termosAceito) setShowModalTermos(true); else setTermosAceito(false); }}
              className="w-full flex items-start gap-3 text-left"
              style={{
                padding: 16, borderRadius: 18,
                background: termosAceito ? 'rgba(58,102,66,0.07)' : '#ffffff',
                border: `1px solid ${termosAceito ? 'rgba(58,102,66,0.3)' : 'rgba(180,190,160,0.65)'}`,
                cursor: 'pointer', transition: 'all 0.18s',
              }}
            >
              <div style={{
                width: 18, height: 18, borderRadius: 5, flexShrink: 0, marginTop: 1,
                background: termosAceito ? '#434e2a' : '#ffffff',
                border: `2px solid ${termosAceito ? '#434e2a' : 'rgba(180,190,160,0.85)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.15s',
              }}>
                {termosAceito && <CheckCircle size={12} color="#ffffff" weight="fill" />}
              </div>
              <div className="flex items-start gap-2 min-w-0">
                <LockKey size={15} color="#434e2a" style={{ flexShrink: 0, marginTop: 1 }} />
                <p className="t-caption" style={{ color: '#5a6642', lineHeight: 1.55 }}>
                  Li e concordo com os{' '}
                  <span style={{ fontWeight: 600, color: '#434e2a', textDecoration: 'underline' }}>
                    Termos de Consentimento e Privacidade
                  </span>
                  {' '}(LGPD, Código Penal Militar e RDE).
                  {!termosAceito && <span style={{ color: '#9b1c1c', fontWeight: 600 }}> Obrigatório para prosseguir.</span>}
                </p>
              </div>
            </button>

            <button type="submit" disabled={loading || !termosAceito || !!emailFeedback} className="btn btn-primary btn-lg w-full">
              {loading
                ? <><SpinnerGap size={18} className="animate-spin" /><span>Enviando solicitação…</span></>
                : <><CheckCircle size={18} /><span>Enviar solicitação de acesso</span></>
              }
            </button>

            <p className="text-center t-caption" style={{ color: '#8a9475' }}>
              Já tem uma conta?{' '}
              <button type="button" onClick={() => onNavigate('/auth/login')}
                style={{ color: '#434e2a', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline', fontSize: 'inherit' }}>
                Entrar no sistema
              </button>
            </p>
          </form>
        </motion.div>
      </main>

      <ModalTermos
        open={showModalTermos}
        onClose={() => setShowModalTermos(false)}
        onAccept={() => setTermosAceito(true)}
      />

      <footer className="relative z-10 py-4 flex flex-wrap items-center justify-center gap-4 px-6">
        <span style={{ fontSize: 12, color: 'rgba(244,246,238,0.40)' }}>SisCMat © 2026 — Uso Restrito e Interno · Exército Brasileiro</span>
        <span style={{ color: 'rgba(255,255,255,0.15)' }}>•</span>
        <span style={{ fontSize: 12, fontWeight: 600, color: 'rgba(244,246,238,0.55)' }}>Created by Ackley Labs</span>
      </footer>
    </div>
  );
}
