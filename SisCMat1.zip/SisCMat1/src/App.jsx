import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home } from './pages/Home.jsx';
import { Login } from './pages/Login.jsx';
import { Cadastro } from './pages/Cadastro.jsx';
import { Dashboard } from './pages/Dashboard.jsx';
import { Materiais } from './pages/Materiais.jsx';
import { Cautelas } from './pages/Cautelas.jsx';
import { Admin } from './pages/Admin.jsx';
import { Sidebar } from './components/Sidebar.jsx';
import { supabase } from './lib/supabaseClient.js';
import './index.css';
import './styles/neomorphism.css';

export default function App() {
  // PÁGINA INICIAL PADRÃO: Home ('/')
  const [currentPath, setCurrentPath] = useState('/');
  const [userPerfil, setUserPerfil] = useState({
    id: 'u-admin-demo',
    nome_completo: 'Marcos Ribeiro',
    nome_guerra: 'Marcos Ribeiro',
    posto_graduacao: '3º Sgt',
    nivel_acesso: 'Administrator',
    status_aprovacao: 'Approved',
    secao_solicitada: 'Seção de Suprimento',
    secao: { id: 's1', nome: 'Seção de Suprimento', sigla: 'SUPRIMENTO' },
    ativo: true
  });

  useEffect(() => {
    // Verificar sessão existente do Supabase no carregamento inicial
    async function checkSession() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          const { data: perfil } = await supabase
            .from('perfis')
            .select('*, secao:secoes(*)')
            .eq('id', session.user.id)
            .maybeSingle();

          if (perfil && perfil.status_aprovacao === 'Approved') {
            setUserPerfil(perfil);
          }
        }
      } catch (err) {
        console.warn('Sessão inicial não encontrada no Supabase, usando modo demo:', err);
      }
    }
    checkSession();
  }, []);

  const handleNavigate = (path) => {
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLoginSuccess = (perfil) => {
    if (perfil) setUserPerfil(perfil);
    setCurrentPath('/app/dashboard');
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('Signout:', e);
    }
    setCurrentPath('/auth/login');
  };

  const isAppRoute = currentPath.startsWith('/app/');

  return (
    <div className="min-h-screen bg-[#eef1e6] text-[#2d371b] font-sans flex flex-col md:flex-row">
      
      {/* Sidebar Compartilhada para Rotas Protegidas /app/* */}
      {isAppRoute && (
        <Sidebar
          currentPath={currentPath}
          onNavigate={handleNavigate}
          userPerfil={userPerfil}
          onLogout={handleLogout}
        />
      )}

      {/* Área de Conteúdo Principal */}
      <div className={`flex-1 flex flex-col min-w-0 ${isAppRoute ? 'pb-24 md:pb-8' : ''}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPath}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
            className="w-full flex-1"
          >
            {currentPath === '/' && <Home onNavigate={handleNavigate} />}
            {currentPath === '/auth/login' && (
              <Login onNavigate={handleNavigate} onLoginSuccess={handleLoginSuccess} />
            )}
            {currentPath === '/auth/cadastro' && <Cadastro onNavigate={handleNavigate} />}
            {currentPath === '/app/dashboard' && (
              <Dashboard userPerfil={userPerfil} onNavigate={handleNavigate} onLogout={handleLogout} />
            )}
            {currentPath === '/app/materiais' && (
              <Materiais userPerfil={userPerfil} onLogout={handleLogout} />
            )}
            {currentPath === '/app/cautelas' && (
              <Cautelas userPerfil={userPerfil} onLogout={handleLogout} />
            )}
            {currentPath === '/app/admin' && (
              <Admin userPerfil={userPerfil} onLogout={handleLogout} />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

    </div>
  );
}
