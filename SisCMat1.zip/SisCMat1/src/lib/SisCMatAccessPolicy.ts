/**
 * SisCMatAccessPolicy.ts
 * Matriz de controle de acesso (RBAC + ABAC) para o SisCMat
 * Suporta perfis: User, Material Operator, Section Chief, Administrator, Auditor
 */

export type RoleProfile = 
  | "User" 
  | "Material Operator" 
  | "Section Chief" 
  | "Administrator" 
  | "Auditor";

export type ModuleKey = "dashboard" | "materiais" | "cautelas" | "admin";

export type ActionKey = 
  | "view" 
  | "create" 
  | "edit" 
  | "approve" 
  | "managePermissions" 
  | "readAudit";

export const ROLE_LABELS: Record<RoleProfile, string> = {
  User: "Usuário",
  "Material Operator": "Operador de Material",
  "Section Chief": "Chefe de Seção",
  Administrator: "Administrador",
  Auditor: "Auditor"
};

export const VALID_ACTIONS_BY_MODULE: Record<ModuleKey, ActionKey[]> = {
  dashboard: ["view"],
  materiais: ["view", "create", "edit"],
  cautelas: ["view", "create", "approve"],
  admin: ["view", "managePermissions", "readAudit"]
};

export const PERMISSION_MATRIX: Record<RoleProfile, Record<ModuleKey, ActionKey[]>> = {
  User: {
    dashboard: ["view"],
    materiais: ["view"],
    cautelas: ["view", "create"],
    admin: []
  },
  "Material Operator": {
    dashboard: ["view"],
    materiais: ["view", "create", "edit"],
    cautelas: ["view", "create", "approve"],
    admin: []
  },
  "Section Chief": {
    dashboard: ["view"],
    materiais: ["view", "create", "edit"],
    cautelas: ["view", "create", "approve"],
    admin: ["view"]
  },
  Administrator: {
    dashboard: ["view"],
    materiais: ["view", "create", "edit"],
    cautelas: ["view", "create", "approve"],
    admin: ["view", "managePermissions", "readAudit"]
  },
  Auditor: {
    dashboard: ["view"],
    materiais: ["view"],
    cautelas: ["view"],
    admin: ["view", "readAudit"]
  }
};

export function clonePermissions(role: RoleProfile): Record<ModuleKey, ActionKey[]> {
  const base = PERMISSION_MATRIX[role] || PERMISSION_MATRIX.User;
  return {
    dashboard: [...base.dashboard],
    materiais: [...base.materiais],
    cautelas: [...base.cautelas],
    admin: [...base.admin]
  };
}

export interface AccessContext {
  targetUserId?: string;
  targetSection?: string;
}

export function canAccess(
  user: {
    id: string;
    role?: RoleProfile;
    nivel_acesso?: RoleProfile;
    secaoEscopo?: string;
    secao_solicitada?: string;
    secao?: { nome: string; sigla: string };
    active?: boolean;
    ativo?: boolean;
    approved?: boolean;
    status_aprovacao?: string;
    customPermissions?: Record<ModuleKey, ActionKey[]>;
  } | null | undefined,
  module: ModuleKey,
  action: ActionKey,
  context?: AccessContext
): boolean {
  if (!user) return false;

  const active = user.active !== undefined ? user.active : user.ativo;
  const approved = user.approved !== undefined ? user.approved : (user.status_aprovacao === 'Approved');

  if (!active || !approved) return false;

  const role = user.role || user.nivel_acesso || 'User';

  // Administrador possui acesso irrestrito
  if (role === 'Administrator') return true;

  const userPerms = user.customPermissions || PERMISSION_MATRIX[role];
  const moduleActions = userPerms ? (userPerms[module] || []) : [];

  if (!moduleActions.includes(action)) return false;

  return true;
}
