import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://gvaensyydjfmnfalrpxa.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd2YWVuc3l5ZGpmbW5mYWxycHhhIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MDg5NzUyNywiZXhwIjoyMTA2NDczNTI3fQ.Jqezd_EwO1-i6CFc_Y9eDqhfHrSvCCZEG_Itv3Ggf90';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testSupabaseHttp() {
  console.log('Testando conexão com Supabase REST API...');
  try {
    const { data, error } = await supabase.from('secoes').select('*').limit(5);
    if (error) {
      console.log('API acessada! Retorno de erro esperado se as tabelas ainda não foram rodadas no SQL Editor:', error.message);
    } else {
      console.log('CONECTADO COM SUCESSO AO SUPABASE! Seções:', data);
    }
  } catch (err) {
    console.error('Erro na requisição:', err);
  }
}

testSupabaseHttp();
