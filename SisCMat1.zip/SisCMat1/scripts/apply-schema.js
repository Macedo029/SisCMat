import fs from 'fs';
import path from 'path';
import pg from 'pg';

const { Client } = pg;

// Supabase Pooler URL para a região sa-east-1 (São Paulo) com o ref do projeto gvaensyydjfmnfalrpxa
const connectionStrings = [
  'postgresql://postgres.gvaensyydjfmnfalrpxa:%40SisCMat%402026.@aws-0-sa-east-1.pooler.supabase.com:5432/postgres',
  'postgresql://postgres.gvaensyydjfmnfalrpxa:%40SisCMat%402026.@aws-0-sa-east-1.pooler.supabase.com:6543/postgres',
  'postgresql://postgres.gvaensyydjfmnfalrpxa:%40SisCMat%402026.@aws-0-us-east-1.pooler.supabase.com:5432/postgres',
  'postgresql://postgres.gvaensyydjfmnfalrpxa:%40SisCMat%402026.@aws-0-us-east-1.pooler.supabase.com:6543/postgres'
];

async function run() {
  let client = null;
  let successUrl = null;

  for (const connStr of connectionStrings) {
    console.log(`Tentando conectar via pooler: ${connStr.replace(/:%40[^@]+@/, ':***@')}...`);
    const testClient = new Client({
      connectionString: connStr,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 5000
    });

    try {
      await testClient.connect();
      console.log('CONECTADO COM SUCESSO!');
      client = testClient;
      successUrl = connStr;
      break;
    } catch (e) {
      console.log(`Erro nesta porta/host (${e.message}). Tentando próximo...`);
      await testClient.end().catch(() => {});
    }
  }

  if (!client) {
    console.error('Não foi possível conectar ao banco através do Pooler.');
    process.exit(1);
  }

  try {
    const sqlPath = path.resolve('supabase/schema.sql');
    const sql = fs.readFileSync(sqlPath, 'utf8');

    console.log('Executando schema.sql no banco remoto...');
    await client.query(sql);
    console.log('\n======================================================');
    console.log('SCHEMA SQL EXECUTADO COM SUCESSO NO SUPABASE!');
    console.log('======================================================\n');

    const res = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public';
    `);
    console.log('Tabelas verificadas no schema public:', res.rows.map(r => r.table_name));

  } catch (err) {
    console.error('Erro ao executar queries:', err);
    process.exit(1);
  } finally {
    await client.end();
  }
}

run();
