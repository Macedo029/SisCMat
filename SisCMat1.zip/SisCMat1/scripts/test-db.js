import dns from 'dns';
import pg from 'pg';

const { Client } = pg;

// Hostnames comuns do Supabase
const projectRef = 'gvaensyydjfmnfalrpxa';
const pass = '%40SisCMat%402026.';

const candidates = [
  `postgresql://postgres.${projectRef}:${pass}@aws-0-sa-east-1.pooler.supabase.com:6543/postgres`,
  `postgresql://postgres.${projectRef}:${pass}@aws-0-sa-east-1.pooler.supabase.com:5432/postgres`,
  `postgresql://postgres.${projectRef}:${pass}@aws-0-us-east-1.pooler.supabase.com:6543/postgres`,
  `postgresql://postgres:${pass}@db.${projectRef}.supabase.co:5432/postgres`
];

async function testConnections() {
  for (const connStr of candidates) {
    const host = connStr.split('@')[1].split(':')[0];
    console.log(`Testando host: ${host}...`);
    try {
      await dns.promises.lookup(host);
      console.log(`DNS resolvido com sucesso para ${host}! Tentando conectar via pg...`);
      const client = new Client({ connectionString: connStr, ssl: { rejectUnauthorized: false } });
      await client.connect();
      console.log(`>>> SUCESSO DE CONEXÃO COM: ${connStr}`);
      await client.end();
      return connStr;
    } catch (e) {
      console.log(`Falha em ${host}: ${e.message}`);
    }
  }
}

testConnections();
