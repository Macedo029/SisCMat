# Regras e Diretrizes do Projeto SisCMat

## 1. Visão Geral do Sistema
- **Nome:** SisCMat (Sistema de Controle de Materiais e Cautela Militar).
- **Domínio:** Exército Brasileiro (EB) — Uso interno restrito em Batalhões e Organizações Militares (OM).
- **Objetivo:** Blindar a cadeia de custódia digital de armamentos, equipamentos e suprimentos, substituindo cautelas impressas por registros com fotos em lote, números de lacre físico e controle de patrimônio.

## 2. Tecnologias & UI Framework
- **Front-End:** React + Vite + TailwindCSS.
- **Design Visual:** Soft-Neomorphism (`rounded-neo` = `border-radius: 24px`, `backdrop-blur: 16px`, profundidade com sombras suaves).
- **Conceito Antigravity:** Animações fluidas em camadas Z-index com micro-oscilação vertical via Framer Motion / CSS keyframes (`animate-antigravity-float`).
- **Icons:** **PROIBIDO O USO DE EMOJIS!** Usar estritamente ícones SVG da biblioteca `@phosphor-icons/react`.

## 3. Back-End & Persistência
- **Banco de Dados:** Supabase PostgreSQL com RLS ativado em todas as tabelas.
- **Sessão:** Autenticação via CPF e Senha, com token JWT mantido localmente por 90 dias (`storageKey: 'siscmat_session_token_90d'`).
- **Níveis de Acesso (`nivel_acesso`):**
  1. `Militar`: Consulta catálogo de sua seção, solicita cautela, visualiza histórico.
  2. `Chefe de Seção`: Autoriza/encerra cautelas, insere materiais com lacres, gerencia sua equipe.
  3. `Administrador`: Acesso total e irrestrito a todas as seções da OM, cria seções e define privilégios.
- **Rastreabilidade:** PROIBIDO Hard Delete em cautelas. Cautelas encerradas mudam o status para `'devolvida'` para auditoria permanente e passagem de comando.
